## Application Details
|               |
| ------------- |
|**Generation Date and Time**<br>Thu Jun 12 2025 09:49:22 GMT+0700 (Indochina Time)|
|**App Generator**<br>@sap/generator-fiori-elements|
|**App Generator Version**<br>1.17.0|
|**Generation Platform**<br>Visual Studio Code|
|**Template Used**<br>List Report Page V2|
|**Service Type**<br>SAP System (ABAP On Premise)|
|**Service URL**<br>http://dcdevsap01.pvgas.com.vn:8080/sap/opu/odata/sap/ZUI_IM_STOCKAGIN_O2|
|**Module Name**<br>zrmmim07|
|**Application Title**<br>Báo cáo thời gian tồn kho vật tư|
|**Namespace**<br>ngs.pvgas|
|**UI5 Theme**<br>sap_horizon|
|**UI5 Version**<br>1.120.23|
|**Enable Code Assist Libraries**<br>False|
|**Enable TypeScript**<br>False|
|**Add Eslint configuration**<br>False|
|**Main Entity**<br>ZC_IM_RMMIM07_U|

## zrmmim07

Báo cáo thời gian tồn kho vật tư

### Starting the generated app

-   This app has been generated using the SAP Fiori tools - App Generator, as part of the SAP Fiori tools suite.  In order to launch the generated app, simply run the following from the generated app root folder:

```
    npm start
```

- It is also possible to run the application using mock data that reflects the OData Service URL supplied during application generation.  In order to run the application with Mock Data, run the following from the generated app root folder:

```
    npm run start-mock
```

#### Pre-requisites:

1. Active NodeJS LTS (Long Term Support) version and associated supported NPM version.  (See https://nodejs.org)


