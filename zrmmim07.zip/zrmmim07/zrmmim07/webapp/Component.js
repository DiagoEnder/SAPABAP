sap.ui.define(
    ["sap/suite/ui/generic/template/lib/AppComponent"],
    function (Component) {
        "use strict";

        return Component.extend("ngs.pvgas.zrmmim07.Component", {
            metadata: {
                manifest: "json"
            }
        });
    }
);