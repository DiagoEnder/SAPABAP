/**
 * @fileOverview Tiện ích hỗ trợ xử lý Filter Bar trong ứng dụng SAPUI5.
 */

sap.ui.define(
  [
    "sap/ui/model/Filter",
    "sap/ui/core/format/DateFormat",
    "sap/ui/model/FilterOperator",
  ],
  function (Filter, DateFormat, FilterOperator) {
    "use strict";

    /**
     * Tạo mảng bộ lọc từ các giá trị đầu vào.
     * @param {Object} oFilter - Đối tượng bộ lọc.
     * @param {string} sFileName - Tên file.
     */
    const createFilterArray = (oFilter) => {

      if (!oFilter) {
        return "";
      }

      // Khởi tạo mảng aFilters nếu chưa tồn tại
      if (!oFilter.aFilters) {
        oFilter.aFilters = [];
      }
      oFilter.band = true;

      const arrFilters = [];
      // Duyệt qua các bộ lọc trong oFilter
      if (oFilter.aFilters && Array.isArray(oFilter.aFilters)) {
        for (let i = 0; i < oFilter.aFilters.length; i++) {
          const subFilterGroup = oFilter.aFilters[i];
          // Kiểm tra nếu subFilterGroup có aFilters (lồng nhau)
          if (
            subFilterGroup.aFilters &&
            Array.isArray(subFilterGroup.aFilters)
          ) {
            for (let j = 0; j < subFilterGroup.aFilters.length; j++) {
              const filter = subFilterGroup.aFilters[j];
              const sPath = filter.sPath;
              const sOperator = filter.sOperator;
              const oValue1 = filter.oValue1;
              const oValue2 = filter.oValue2;
            
              
               debugger;
              if (sPath === "ReferenceDate") {
                const dateFilter = _createFilter(
                  { operator: sOperator, values: [oValue1, oValue2] },
                  sPath
                );
                if (dateFilter) {
                  arrFilters.push(dateFilter);
                }
              } else if (sPath) {
                arrFilters.push(
                  new Filter({
                    path: sPath,
                    operator: sOperator,
                    value1: oValue1,
                    value2: oValue2,
                  })
                );
              }
            }
          } else {
            // Nếu không có aFilters, xử lý như một bộ lọc đơn
            const sPath = subFilterGroup.sPath;
            const sOperator = subFilterGroup.sOperator;
            const oValue1 = subFilterGroup.oValue1;
            const oValue2 = subFilterGroup.oValue2;

            if (sPath === "ReferenceDate") {
              const dateFilter = _createFilter(
                { operator: sOperator, values: [oValue1, oValue2] },
                sPath
              );
              if (dateFilter) {
                arrFilters.push(dateFilter);
              }
            } else {
              arrFilters.push(
                new Filter({
                  path: sPath,
                  operator: sOperator,
                  value1: oValue1,
                  value2: oValue2,
                })
              );
            }
          }
        }
      }
      return arrFilters;
    };

    /**
     * Khởi tạo Filter Bar và gắn sự kiện FilterChange.
     * @param {Object} oController - Đối tượng controller.
     * @param {string} sFilterBarId - ID của Filter Bar.
     * @returns {sap.ui.comp.smartfilterbar.SmartFilterBar|null} Đối tượng Filter Bar hoặc null nếu không tìm thấy.
     */
    const initializeFilterBar = (oController, sFilterBarId) => {
      const oFilterBar = oController.getView().byId(sFilterBarId);
      if (!oFilterBar) {
        return null;
      }
      // Gắn sự kiện FilterChange
      oFilterBar.attachFilterChange(
        oController._onFilterChange.bind(oController)
      );
      return oFilterBar;
    };

    /**
     * Tạo bộ lọc cho các trường ngày
     * @param {object} oValue - Giá trị của điều kiện lọc
     * @param {string} sFieldNameFilter - Tên của trường lọc
     * @returns {object|Array} - Bộ lọc đã tạo hoặc mảng các bộ lọc
     */
    const _createFilter = (oValue, sFieldNameFilter) => {
      if (oValue) {
        let aDates = [];
        if (oValue.values && Array.isArray(oValue.values)) {
          aDates = oValue.values.map((value) =>
            value ? new Date(value) : null
          );
        }
        aDates = aDates.map((date) => {
          if (!date) return null;
          const yyyy = date.getFullYear();
          const mm = String(date.getMonth() + 1).padStart(2, "0");
          const dd = String(date.getDate()).padStart(2, "0");
          return `${yyyy}-${mm}-${dd}T00:00:00`;
        });

        if (oValue.operator === "GE") {
          return new Filter(sFieldNameFilter, FilterOperator.GE, aDates[0]);
        } else if (oValue.operator === "LE") {
          return new Filter(sFieldNameFilter, FilterOperator.LE, aDates[0]);
        }
        // Default là BT
        return new Filter(
          sFieldNameFilter,
          FilterOperator.BT,
          aDates[0],
          aDates[1]
        );
      }
      return null;
    };

    /**
     * Khởi tạo bảng và gắn sự kiện rowsUpdated.
     * @param {Object} oController - Đối tượng controller.
     * @param {string} sTableId - ID của bảng.
     * @returns {sap.ui.table.Table|null} Đối tượng bảng hoặc null nếu không tìm thấy.
     */
    const initializeTable = (oController, sTableId) => {
      const oTable = oController.getView().byId(sTableId);
      if (!oTable) {
        return null;
      }

      // Gắn sự kiện rowsUpdated
      oTable.attachEvent(
        "rowsUpdated",
        oController.onTableDataUpdateFinished.bind(oController)
      );

      return oTable;
    };

    return {
      createFilterArray,
      initializeFilterBar,
      _createFilter,
      initializeTable,
    };
  }
);