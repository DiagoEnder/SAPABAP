sap.ui.define(["sap/m/MessageBox"], function (MessageBox) {
    "use strict";
  
    return {
      /**
       * Tạo liên kết tải xuống cho file Word và kích hoạt tải file.
       *
       * @function
       * @param {object} sObject - Đối tượng chứa thông tin file.
       * @param {string} sObject.UploadFileContentBinary - Nội dung file được mã hóa Base64.
       * @param {string} sObject.MimeType - Loại MIME của file (ví dụ: "application/vnd.openxmlformats-officedocument.wordprocessingml.document").
       * @param {string} sObject.FileName - Tên file sẽ được tải xuống.
       * @param {object} oExtensionAPI - API mở rộng để truy cập các mô hình và tài nguyên.
       * @param {sap.ui.model.Model} oExtensionAPI.getModel - Hàm để lấy mô hình theo tên.
       * @throws {Error} Hiển thị thông báo lỗi nếu nội dung file trống.
       */
      generateWordDownloadLink: function (sObject, oExtensionAPI) {
        var sBase64 = sObject.UploadFileContentBinary;
        var sMimeType = sObject.MimeType;
        var sFileName = sObject.FileName;
        // Kiểm tra nếu nội dung file trống
        if (!sBase64) {
          var oResourceBundle = oExtensionAPI
            .getModel("i18n")
            .getResourceBundle();
          MessageBox.error(oResourceBundle.getText("errorFileContentEmpty"));
          return;
        }
        // Giải mã nội dung Base64
        var byteCharacters = atob(sBase64);
        var byteNumbers = new Array(byteCharacters.length);
        for (var i = 0; i < byteCharacters.length; i++) {
          byteNumbers[i] = byteCharacters.charCodeAt(i);
        }
        // Tạo file Blob từ nội dung
        var byteArray = new Uint8Array(byteNumbers);
        var blob = new Blob([byteArray], {
          type: sMimeType,
        });
        // Tạo liên kết tải xuống và kích hoạt tải file
        var link = document.createElement("a");
        link.href = URL.createObjectURL(blob);
        link.download = sFileName;
        document.body.appendChild(link);
        link.click();
        document.body.removeChild(link);
      },
    };
  });
  