/**
 * @fileOverview Tiện ích chứa các hằng số và hàm hỗ trợ cho ứng dụng SAPUI5.
 */

sap.ui.define(
    ["sap/m/MenuButton", "sap/m/Menu", "sap/m/MenuItem"],
    () => {
      "use strict";
  
      /**
       * Tên file mặc định.
       * @constant {string}
       */
      const FILE_NAME = "Material_Stock_Aging_Report";
  
      /**
       * ID của ứng dụng.
       * @constant {string}
       */
      const ID_APP = "R.MM.IM.09";
  
      /**
       * Loại MIME mặc định.
       * @constant {string}
       */
      const MIME_TYPE_KEY = "XLSX";
  
      /**
       * ID của manifest ứng dụng.
       * @constant {string}
       */
      const ID_MANIFEST = "ngs.pvgas.zrmmim09";
      /**
       * Lấy các thông tin liên quan để xuất file.
       * @returns {Object} Đối tượng chứa thông tin và metadata.
       */
      const getOSignatureArea = () => {
        const fileName = FILE_NAME;
  
        return {
          IdApp: ID_APP,
          Reservation: "",
          FileName: fileName,
          MimeType: MIME_TYPE_KEY,
        };
      };
  
      return {
        ID_MANIFEST,
        getOSignatureArea,
      };
    }
  );