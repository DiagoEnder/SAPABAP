sap.ui.define(
    [
        "../utils/ExportFileUtil",
        "../utils/FilterBarUtil",
        "sap/ui/core/BusyIndicator",
        "sap/m/MessageToast",
    ]
    , function (ExportFileUtil, FilterBarUtil, BusyIndicator, MessageToast) {
        'use strict';

        return {
            ExportFileUtil: ExportFileUtil,
            /**
          * Handle Filter Bar.
          * @type {Object}
          */
            filterBarUtil: FilterBarUtil,
            /**
          * Hàm khởi tạo controller.
          * Thiết lập mô hình JSON cục bộ và lấy các control UI chính.
          */
            onInit: function () {

                this._oFilterBar = this.fnGetViewControl(this, "listReportFilter");
                this._oListReport = this.fnGetViewControl(this, "listReport");
                this._oTable = this.fnGetViewControl(this, "analyticalTable");
                this.oI18nModel = this.getOwnerComponent()
                    .getModel("i18n")
                    .getResourceBundle();
            },

            fnGetViewControl: function (
                oController,
                sComponentId = "AnalyticalTable"
            ) {
                const sControlId = `${oController.getView().getId()}--${sComponentId}`;
                const oControl = oController.getView().byId(sControlId);
                return oControl;
            },

             ExportExcel: function (oEvent) {
                var oI18nModel = this.oI18nModel;
                BusyIndicator.show(0);

                var oFilterList = this._oFilterBar.getFilters();

                const filterArray = this.filterBarUtil.createFilterArray(
                    oFilterList[0]
                );
            
                var oModel = this.getView().getModel();
                oModel.read("/ExportFile", {
                    filters: filterArray, // truyền filter array đã build
                    urlParameters: {
                        $select: "FileName,MimeType,UploadFileContentBinary",
                    },
                    success: function (oData) {
                        if (
                            oData &&
                            oData.results &&
                            oData.results.length > 0 &&
                            oData.results[0].UploadFileContentBinary !== ""
                        ) {
                            const sObject = {
                                UploadFileContentBinary:
                                    oData.results[0].UploadFileContentBinary,
                                FileName: oData.results[0].FileName,
                            };

                            ExportFileUtil.generateWordDownloadLink(sObject, this);
                        } else {
                            MessageToast.show(oI18nModel.getText("txtNoDataErr"));
                        }
                        BusyIndicator.hide();
                        this.oExportDialog.then(function (oDialog) {
                            oModel.resetChanges();
                            oDialog.close();
                        });
                    }.bind(this),
                    error: function () {
                        BusyIndicator.hide();
                        MessageToast.show(oI18nModel.getText("txtExportErr"));
                    },
                });
                // MessageToast.show("Custom handler invoked.");
            }
        };
    });