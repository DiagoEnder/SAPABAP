const APP_MODULE = `zcmmpur01his`;
const APP_NAMESPACE = `ngs.pvgas.${APP_MODULE}`;
const FRAGMENT_PATH = `${APP_NAMESPACE}.ext.fragments.`;

sap.ui.define(
  [
    `ngs/pvgas/${APP_MODULE}/ext/controller/Core.controller`,
    "sap/ui/model/json/JSONModel",
    "sap/ui/model/Filter",
    "sap/m/Button",
    "sap/m/MessageBox",
    "sap/m/Token",
  ],

  function (Core, JSONModel, Filter, Button, MessageBox, Token) {
    "use strict";

    return {
      onInit: function () {
        const oJSONData = {};
        const oModel = new JSONModel(oJSONData);
        this.getView().setModel(oModel, "local");
        this._oView = this.getView();
        this._oComponent = this.getOwnerComponent();
        this._oExtensionAPI = this.extensionAPI;
        this._oFilterBar = Core.fnGetViewControl(this, "listReportFilter");
        this._oListReport = Core.fnGetViewControl(this, "listReport");
        this._oTable = Core.fnGetViewControl(this, "analyticalTable");
        // if (!this._oFilterBar || !this._oListReport || !this._oTable) {
        //   MessageBox.error(Core.getGeneralTechnicalIssueMsg());
        //   return;
        // }
        // this._oButtonGo = Core.fnGetViewControl(this, "listReportFilter-btnGo");

        // xu ly data dau vao
        // let oComponentData = this.getOwnerComponent().getComponentData();
        // let oStartupParams = oComponentData && oComponentData.startupParameters;
        // if (oStartupParams && oStartupParams.MyID) {
        //   const sMyID = oStartupParams.MyID[0]; // luôn là array
        //   console.log("Received MyID:", sMyID);
      
        //   // Gọi filter, binding hoặc hành động tùy vào logic của bạn
        // }
        // else {
        //   const oUriParams = new URLSearchParams(window.location.hash.split("?")[1]);
        //   const sMyID = oUriParams.get("MyID");
        //   console.log("Param from URL:", sMyID);
        // }

        // Trong controller, ví dụ onInit hoặc trước khi set mặc định:
        this.bSuppressFirstSearch = true;
        const oSFB = this._oFilterBar;  // SmartFilterBar instance

        // 2. Lưu lại method nội bộ _triggerSearch
        var fnOrigTrigger = oSFB._triggerSearch;

        // 3. Override thành no‐op
        oSFB._triggerSearch = function() {
          // console.log("Auto‐search bị chặn");
        };

        this._oFilterBar.attachInitialise(
          function (oEvent) {
            this.setDefaultParametersFilterbar();

            oEvent.preventDefault(); // Ngăn chặn hành động mặc định của SmartFilterBar

            // if (this._oListReport) {
            //   this._oListReport.setEnableAutoBinding(false);
            // }

            // Core.fnSetUserDefaultValue(this);
            // this._oFilterBar.search();
            // this._oButtonGo.firePress();

            // setTimeout(function () {
            //   this._oButtonGo.firePress();
            // }.bind(this), 10000);
            // this._oExtensionAPI.rebindTable();
            // this._oFilterBar.search = function() {};
          // }
          }.bind(this)
        );
        
        // 5. Restore method gốc để user bấm GO vẫn hoạt động
        oSFB._triggerSearch = fnOrigTrigger;

        //  filterChange filtersInitialized 

        // this._oFilterBar.attachEventOnce("filtersInitialized",
        //   function (oEvent) {

            // this._oFilterBar.search();

            // const oInnerTable = this._oFilterBar.getTable();

            // if (oInnerTable) {
            //   setTimeout(() => {
            //     const oBinding = oInnerTable.getBinding("items");
            //     if (oBinding) {
            //       oBinding.refresh(true);
            //     }
            //   }, 300);              
            // }

            // oInnerTable.attachEventOnce("dataReceived", () => {
            //   this._oListReport.rebindTable();
            // });
        //   }.bind(this)
        // );

        // this._oFilterBar.attachEventOnce("filterChange",
        //   function (oEvent) {
        //     setTimeout(function () {
        //       this._oFilterBar.search();
        //     }, 5000);
        //   }
        // );
        

        // if (this._oListReport) {
        //   this._oListReport.attachInitialized(
        //     function (oEvent) {
        //       Core.fnSetUserDefaultValue(this);
        //     }.bind(this)
        //   );
        // }

        // this._oListReport.rebindTable();

        // Core.fnAddHistoryButtonToSmartTableToolbar(
        //   this,
        //   this.onPressHistoryDataHandler
        // );

        // Core.fnAddUploadMenuButtonToSmartTableToolbar(
        //   this,
        //   this.onPressUploadDataHandler
        // );

        // Core.fnAddExportMenuButtonToSmartTableToolbar(
        //   this,
        //   this.onPressExportDataHandler
        // );

        // this._oTable.attachEvent(
        //   "rowsUpdated",
        //   this.onTableDataUpdateFinished,
        //   this
        // );
      },
      // onInitSmartFilterBarExtension: function () {
      //   var oView = this.getView();
      //   var sYear = new Date().getFullYear();
      //   var sMonth = new Date().getMonth() + 1;
      //   let sUploadFromDate = new Date();
      //   oView
      //     .byId("listReportFilter")
      //     .getControlByKey("ZZDATE_UPLOAD")
      //     .setValue(sUploadFromDate);
      //   // oView
      //   //   .byId("listReportFilter")
      //   //   .getControlByKey("period_from")
      //   //   .setValue(sMonth);

      // },
      setDefaultParametersFilterbar: function (){

        // const oUriParams = new URLSearchParams(window.location.hash.split("?")[1]);
        // let sUploadFromDate = new Date( decodeURIComponent( oUriParams.get("UploadFromDate") ) );
        // let sUploadToDate = new Date( decodeURIComponent( oUriParams.get("UploadToDate") ) );
        // let sUploadBy = oUriParams.get("UploadBy");
        let sUploadFromDate = new Date();
        let sUploadToDate = new Date();
        // let sUploadBy = 'NGS.E3.TINH';
        const oUser = sap.ushell?.Container?.getUser();
        let sUploadBy = "";
        if (oUser) {
          sUploadBy = oUser.getId();           // Mã người dùng (User ID)
        }

        const currentVariantId = this._oFilterBar.getCurrentVariantId();      
        if (currentVariantId == "" || currentVariantId == "standard") {

          if (sUploadBy) {
            const oUploadByController = this._oFilterBar.getControlByKey("ZZUSER_UPLOAD");     
            let aDefaultTokens = [];
            aDefaultTokens.push(
              new Token({
                key: sUploadBy,
                text: `${( sUploadBy )}`,
                }),
            );
            oUploadByController.setTokens(aDefaultTokens);
          }

          const oDate_UploadController =
          this._oFilterBar.getControlByKey("ZZDATE_UPLOAD");   

          //Create JSON data that contains the Inital value of the filter
          var oDefaultFilter = {
            "ZZDATE_UPLOAD": {
                  ranges: [
                    {
                      // exclude : false,
                      operation : "BT",
                      value1 : sUploadFromDate,
                      value2: sUploadToDate,
                      // tokenText : `${( sUploadFromDate )} - ${( sUploadToDate )}`,
                    },
                  ],
            }
          };

          //Set SmartFilterBar initial values
          this._oFilterBar.setFilterData(oDefaultFilter);

          // let aDefaultTokens = [];
          // aDefaultTokens.push(
          //   new Token({
          //     key: sUploadFromDate,
          //     text: `${( sUploadFromDate )}`,
          //     }),
          // );

          // var oValues = [];
          // oValues.push({
          //   value: sUploadFromDate
          // });

          // var oDefaultDate = {
          //   value: sUploadFromDate,
          //   values: oValues,
          //   operator: "TODAY",
          // }

          // oDate_UploadController.setValue(oDefaultDate);
          // oDate_UploadController.fireChange(true);




        }               
      },

      // modifyStartupExtension: function (oStartupObject) {
        // var oSmartFilterBar = oStartupObject.smartFilterBar;
        // Xóa variant hiện tại (nếu có)
        // oStartupObject.clearVariantSelection();

        // if (this._oFilterBar.isInitialised()){
        //   this.setDefaultParametersFilterbar();
        //   // this._oFilterBar.refresh();

        //   let otable = this._oListReport.getTable();

        //   otable.bindRows({
        //     path: "/HIS01",
        //     parameters: {
        //       $filter: "ZZUSER_UPLOAD eq '" + "'",  
        //     }
        //   });
        //   this._oListReport.rebindTable();

        //   // this._oFilterBar.fireSearch();
        // } else {
        //   this._oFilterBar.attachInitialise(
        //     function (oEvent) {
        //       this.setDefaultParametersFilterbar();
        //       this._oFilterBar.refresh();

        //       let otable = this._oListReport.getTable();

        //       otable.bindRows({
        //         path: "/HIS01",
        //         parameters: {
        //           $filter: "ZZUSER_UPLOAD eq '" + "'",  
        //         }
        //       });
        //       this._oListReport.rebindTable();

        //       // this._oFilterBar.fireSearch();
        //     }.bind(this)
        //   );
        // }
        // console.log("🔥 modifyStartupExtension CALLED!");

        // let otable = this._oListReport.getTable();

        // otable.bindRows({
        //   path: "/HIS01",
        //   parameters: {
        //     $filter: "ZZUSER_UPLOAD eq '" + "'",  
        //   }
        // });
        // this._oListReport.rebindTable();

      // },
      // onBeforeRebindTableExtension: function (oEvent) {
      //   console.log("🔥 onBeforeRebindTableExtension CALLED!");

      //   let oTable = this._oListReport.getTable();

      //   if (this._countRefesh) {
      //     this._countRefesh += 1;
      //   } else {
      //     this._countRefesh = 1; 
      //   }

      //   // if (oTable && this._countRefesh < 10) {
      //   //   if (!oTable.getBinding("rows")) {
      //   //     setTimeout(function (){
  
      //   //       // Something you want delayed.
    
      //   //       this.setDefaultParametersFilterbar();
    
      //   //       oTable.bindRows({
      //   //         path: "/HIS01",
      //   //         parameters: {
      //   //           $filter: "ZZUSER_UPLOAD eq '" + "'",  
      //   //         }
      //   //       });
      //   //       this._oListReport.rebindTable();              


      //   //     }.bind(this), 1000);

      //   //   }
      //   // }




      //   if (this._countRefesh > 1){
      //     oTable.attachEventOnce("rowsUpdated", () => {
      //       const aColumns = oTable.getColumns();
      //       aColumns.forEach((oColumn, index) => {
      //         const oLabel = oColumn.getLabel();
      //         if (oLabel?.getText?.() === "Status") {
      //           // const oTemplate = new sap.m.Text({
      //           //   text: {
      //           //     path: "Status",
      //           //     formatter: function (sStatus) {
      //           //       // Gắn class qua DOM tại đây
      //           //       setTimeout(() => {
      //           //         const oDomRef = this.getDomRef?.();
      //           //         if (oDomRef) {
      //           //           oDomRef.classList.remove("statusErrorColor", "statusSuccessColor");
      //           //           if (sStatus === "Error") {
      //           //             oDomRef.classList.add("statusErrorColor");
      //           //           } else if (sStatus === "Success") {
      //           //             oDomRef.classList.add("statusSuccessColor");
      //           //           }
      //           //         }
      //           //       });                    
      //           //       return sStatus;
      //           //     }
      //           //   }
      //           // });

      //           const oTemplate = new sap.m.ObjectStatus({
      //             text: "{Status}",
      //             state: {
      //               path: "Status",
      //               formatter: function (sStatus) {
      //                 switch (sStatus) {
      //                   case "Error": return "Error";     // đỏ
      //                   case "Success": return "Success"; // xanh lá
      //                   case "Warning": return "Warning"; // vàng
      //                   default: return "None";           // mặc định
      //                 }
      //               }
      //             }
      //           });

      //           oTemplate.addStyleClass("boldStatusText");

      //           oColumn.setTemplate(oTemplate);
      //         }
  
      //         // if (oLabel?.getText?.() === "ZZMESSAGE") {
      //         //   oColumn.setWidth("auto");
      //         // }
  
      //       });
      //     });          
      //   }
  
        
      // },
      // onInitSmartFilterBar: function (oEvent) {
        // // debugger;
        // console.log("🔥 onBeforeRebindTableExtension CALLED!");
        // const oUriParams = new URLSearchParams(window.location.hash.split("?")[1]);
        // let sUploadFromDate = decodeURIComponent( oUriParams.get("UploadFromDate") );
        // let sUploadToDate = decodeURIComponent( oUriParams.get("UploadToDate") );
        // let sUploadBy = oUriParams.get("UploadBy");

        // // let sUploadFromDate = new Date();
        // // let sUploadToDate = new Date();
        // // let sUploadBy = "NGS.E3.TINH";

        // const currentVariantId = this._oFilterBar.getCurrentVariantId();      
        // if (currentVariantId == "" || currentVariantId == "standard") {

        //   const oUploadByController = this._oFilterBar.getControlByKey("ZZUSER_UPLOAD");     
        //   let aDefaultTokens = [];
        //   aDefaultTokens.push(
        //     new Token({
        //       key: sUploadBy,
        //       }),
        //   );
        //   oUploadByController.setTokens(aDefaultTokens);

        //   const oDate_UploadController =
        //   this._oFilterBar.getControlByKey("ZZDATE_UPLOAD");   

        //   //Create JSON data that contains the Inital value of the filter
        //   var oDefaultFilter = {
        //     "ZZDATE_UPLOAD": {
        //           ranges: [
        //             {
        //               exclude : false,
        //               operation : "BT",
        //               value1 : sUploadFromDate,
        //               value2: sUploadToDate,
        //               tokenText : `${( sUploadFromDate )} - ${( sUploadToDate )}`,
        //             },
        //           ],
        //     }
        //   };

        //   //Set SmartFilterBar initial values
        //   this._oFilterBar.setFilterData(oDefaultFilter);

        //   this._oListReport.rebindTable();
        // }               
      // },
    
      // onAfterBinding: function () {
      //   console.log("🔥 onAfterBinding called");
      // },

      // onAfterRendering: function () {
        // this._oListReport.rebindTable();
        // const oSmartFilterBar = this._oListReport?.getSmartFilter();
      
        // if (oSmartFilterBar) {
        //   // Delay 0 để chắc chắn các control đã render xong
        //   setTimeout(function () {
        //     oSmartFilterBar.search();
        //   }, 0);
        // }

        // if (this._oButtonGo) { 
        //   setTimeout(function () {
        //     this._oButtonGo.firePress();
        //   }, 5000);
        // }


        // if (this._oButtonGo) { 
        //   setTimeout(function () {
        //     this._oButtonGo.firePress();
        //   }.bind(this), 10000);
        // }        
      // },      
      getLanguage: function () {
        return Core.getLanguage();
      },
      // onTableDataUpdateFinished: function (oEvent) {
        // const aRows = this._oTable.getRows();
        // const aColumns = this._oTable.getColumns();
        // for (let i = 0; i < aColumns.length; i++) {
        //   const oColumn = aColumns[i];
        //   //to use this need add annotation @UI.lineItem: [{ position: 10, type: #AS_LINK, label: 'Document Number' }]
        //   // var oTemplate = oColumn.getTemplate();
        //   // if (oTemplate && oTemplate.isA("sap.m.Link")) {
        //   //     oTemplate.attachPress(this.onDocumentLinkPress, this);
        //   // }
        //   const sColumnHeader = oColumn.getLabel().getText(); // Get column header text
        //   if (sColumnHeader === "PDF" || sColumnHeader === "XML") {
        //     if (oColumn.getSummed() === true) {
        //       continue;
        //     }
        //     const oTemplate = oColumn.getTemplate();
        //     if (oTemplate && oTemplate.isA("sap.m.Text")) {
        //       const oLink = new sap.m.Link({
        //         text: oTemplate
        //           .getBindingInfo("text")
        //           .parts[0].path.toUpperCase(),
        //         customData: [
        //           new sap.ui.core.CustomData({
        //             key: "docType",
        //             value: oTemplate
        //               .getBindingInfo("text")
        //               .parts[0].path.toUpperCase(),
        //           }),
        //         ],
        //         press: this.onViewAttachments.bind(this),
        //       });
        //       oColumn.setTemplate(oLink);
        //     }
        //   }
        // }

        // for (let i = aRows.length - 5; i < aRows.length; i++) {
        //     const oRow = aRows[i];
        //     const oRowData = oRow.getCells()[1].getText();
        //     console.log(`dsad ${oRowData}`);
        // }
      // },
      onViewAttachments: function (oEvent) {
        try {
          const oView = this.getView();
          const oAttachmentModelData = new JSONModel({
            title: "Attachments",
            items: [],
          });
          this.getView().setModel(oAttachmentModelData, "attachment");
          const oAttachmentModel = this.getView().getModel("attachment");
          const oSourcePress = oEvent.getSource();
          const docType = oSourcePress.getCustomData()[0].getValue();
          oAttachmentModel.setProperty("/title", `${docType} Files`);
          const oRowData = oSourcePress
            .getParent()
            .getBindingContext()
            .getObject();
          const attachmentQuery = `?$filter=((((CompanyCode eq '${oRowData.CompanyCode}')) and ((DocumentNumber eq '${oRowData.DocumentNumber}') and ((formattype eq '${docType}')))))`;
          const sRequestEndpoint = `${
            this.getModel().sServiceUrl
          }/attachment${attachmentQuery}`;
          const oRequestAttachments = Core.fnGetDataV2(this, sRequestEndpoint);
          $.when(oRequestAttachments).done((aContents) => {
            oAttachmentModel.setProperty("/items", aContents);
            if (!this._pAttachment) {
              this._pAttachment = this.loadFragment({
                id: oView.getId(),
                name: `${FRAGMENT_PATH}Attachments`,
                controller: this,
              }).then(function (oPopover) {
                oView.addDependent(oPopover);
                return oPopover;
              });
            }
            this._pAttachment.then(function (oPopover) {
              oPopover.openBy(oSourcePress);
            });
          });
        } catch (error) {
          console.log(`onViewAttachments - Error: ${error.stack}`);
          MessageBox.error(Core.getGeneralTechnicalIssueMsg());
        }
        console.log("onViewAttachments");
      },
      onPressAttachmentItem: function (oEvent) {
        const oSource = oEvent.getSource();
        const oAttachmentData = oSource
          .getBindingContext("attachment")
          .getObject();
        if (oAttachmentData.DownloadFileContentBinary) {
          Core.fnDownloadFile(oAttachmentData);
        }
      },
      //START export
      onPressExportDataHandler: async function (outputType) {
        const oController = this.extListReportController;

        try {
          Core.showBusy();
          const exportDataModel = oController.getModel("downloadExcelSrv");
          let aExportFilters = [];

          // if ( outputType === "1" ) {
            let formname = "ZXF_ZCMMPUR01_TEMPLATE_0" + outputType;
          // } else if ( outputType === "2" ) {
          //   formname = "ZXF_ZCMMPUR01_TEMPLATE_02";
          // } else if ( outputType === "3" ) {
          //   formname = "ZXF_ZCMMPUR01_TEMPLATE_03";
          // }

          let oFilter = new sap.ui.model.Filter({
            path : "TemplateName",
            operator : sap.ui.model.FilterOperator.EQ,
            value1 : formname,
          });
          aExportFilters.push(oFilter); 

          // // Filter key mapping for backend naming
          // const mFilterKeyMapping = {
          //   TemplateName: formname,
          // };
          
          const oData = await Core.readData(
            exportDataModel,
            '/DownloadExcel',
            aExportFilters
          );

          if (oData && oData.results && oData.results.length > 0) {
            const oDownloadData = oData.results[0];
            if (oDownloadData.DownloadFileContentBinary) {
              Core.fnDownloadFile(oDownloadData,formname);
              if (this._oExportDataDialog) {
                this._oExportDataDialog.then(function (oDialog) {
                  oDialog.close();
                });
              }
            } else {
              MessageBox.information("No data found for export");
            }
          } else {
            MessageBox.information("No data found");
          }
        } catch (oError) {
          if (oError && oError.message) {
            console.error(
              "Error reading data:",
              oError.message ?? oError.stack
            );
          }
          MessageBox.error(Core.getGeneralTechnicalIssueMsg());
        }


        // let oExportDataModel = new JSONModel({
        //   fileName: "BaoCaoTinhHinhSuDungHanMucTrungDaiHan",
        //   outputType: outputType,
        //   printDate: new Date(),
        // });
        // oController._oView.setModel(oExportDataModel, "exportData");
        // if (!oController._oExportDataDialog) {
        //   oController._oExportDataDialog = oController.loadFragment({
        //     name: `${FRAGMENT_PATH}ExportDialog`,
        //   });
        // }
        // oController._oExportDataDialog.then(
        //   function (oDialog) {
        //     oDialog.open();
        //   }.bind(oController)
        // );
      },
      onCloseExportDataDialog: function () {
        if (this._oExportDataDialog) {
          this._oExportDataDialog.then(function (oDialog) {
            oDialog.close();
          });
        }
      },
      onConfirmExportData: async function () {
        try {
          Core.showBusy();
          const exportDataModel = this.getModel("exportDataModelSrv");
          let aExportFilters = Core.fnGetExportFilters(this);

          const oData = await Core.readData(
            exportDataModel,
            "/ExportExcel",
            aExportFilters
          );
          if (oData && oData.results && oData.results.length > 0) {
            const oDownloadData = oData.results[0];
            if (oDownloadData.DownloadFileContentBinary) {
              Core.fnDownloadFile(oDownloadData);
              if (this._oExportDataDialog) {
                this._oExportDataDialog.then(function (oDialog) {
                  oDialog.close();
                });
              }
            } else {
              MessageBox.information("No data found for export");
            }
          } else {
            MessageBox.information("No data found");
          }
        } catch (oError) {
          if (oError && oError.message) {
            console.error(
              "Error reading data:",
              oError.message ?? oError.stack
            );
          }
          MessageBox.error(Core.getGeneralTechnicalIssueMsg());
        }
      },
      //END export
      getExportSrvPath: function () {
        const oExportSrvModel = this.getModel("exportDataModelSrv");
        if (oExportSrvModel) {
          return `${oExportSrvModel.sServiceUrl}`;
        }
        return "";
      },
      //START Upload
      onPressUploadDataHandler: async function (outputType) {

        const oController = this.extListReportControllerUpload;
        let oUploadDataModel = new JSONModel({
          fileName: "",
          outputType: outputType,
          printDate: new Date(),
          templateName: outputType,
        });
        oController._oView.setModel(oUploadDataModel, "uploadData");
        if (!oController._oUploadDataDialog) {
          oController._oUploadDataDialog = oController.loadFragment({
            name: `${FRAGMENT_PATH}UploadDialog`,
          });
        }
        oController._oUploadDataDialog.then(
          function (oDialog) {
            oDialog.open();
          }.bind(oController)
        ); 

        oController.templateUploadName = "0" + outputType;

      },
      onCloseUploadDataDialog: function () {
        if (this._oUploadDataDialog) {
          this._oUploadDataDialog.then(function (oDialog) {
            oDialog.close();
          });
        } 
      },
      onConfirmUploadData(){
        this.fnUploadFile(this.aFiles[0])
        .then(function (sBase64) {
            // console.log("File converted to Base64:", sBase64);
            this._postData(sBase64);
            if (this._oUploadDataDialog) {
              this._oUploadDataDialog.then(function (oDialog) {
                oDialog.close();
              });
            }
        }.bind(this))
        .catch(function (sError) {
            console.error(sError);
        });
      },          
      onFilePathChange(oEvent) {
        if (this._oUploadDataDialog) {
          this._oUploadDataDialog.then(function (oDialog) {
            let oFileUploader = oEvent.getSource();
            let aFiles = oFileUploader.oFileUpload.files;
            this.sFileName = aFiles[0].name;
            // this.sFileType = aFiles[0].type;
            this.aFiles = aFiles;
          }.bind(this));
        }        
      },
      fnUploadFile: async function (oFile) {
        return new Promise(function (resolve, reject) {
            // Kiểm tra nếu file tồn tại
            if (!oFile) {
                reject("No file provided for upload.");
                return;
            }
    
            // Sử dụng FileReader để đọc file
            var oReader = new FileReader();
    
            // Định nghĩa callback khi đọc file thành công
            oReader.onload = function (oEvent) {
                // Lấy nội dung file dưới dạng Base64
                var sBase64 = oEvent.target.result.split(",")[1]; // Loại bỏ tiền tố "data:*/*;base64,"
                resolve(sBase64); // Trả về chuỗi Base64
            };
    
            // Định nghĩa callback khi đọc file thất bại
            oReader.onerror = function (oError) {
                reject("Error reading file: " + oError.message);
            };
    
            // Đọc file dưới dạng Data URL (Base64)
            let vvrar = oReader.readAsDataURL(oFile);
            
        });
      },      
      onPressHistoryDataHandler: async function (outputType) {
        const oController = this.historyListReportController;

        const oCrossAppNav = sap.ushell.Container.getService("CrossApplicationNavigation");
        oCrossAppNav.toExternal({
          target: {
            semanticObject: "zcmmpur01",
            action: "display"
          },
          params: {
            UploadFromDate : [ "12345" ],
            UploadToDate : [ "54321" ],
            UploadBy : [ "ABC" ],
          }
        });

        // try {
        //   Core.showBusy();
        //   const exportDataModel = oController.getModel("downloadExcelSrv");
        //   let aExportFilters = [];

        //   // if ( outputType === "1" ) {
        //     let formname = "ZXF_ZCMMPUR01_TEMPLATE_0" + outputType;
        //   // } else if ( outputType === "2" ) {
        //   //   formname = "ZXF_ZCMMPUR01_TEMPLATE_02";
        //   // } else if ( outputType === "3" ) {
        //   //   formname = "ZXF_ZCMMPUR01_TEMPLATE_03";
        //   // }

        //   let oFilter = new sap.ui.model.Filter({
        //     path : "TemplateName",
        //     operator : sap.ui.model.FilterOperator.EQ,
        //     value1 : formname,
        //   });
        //   aExportFilters.push(oFilter); 

        //   // // Filter key mapping for backend naming
        //   // const mFilterKeyMapping = {
        //   //   TemplateName: formname,
        //   // };
          
        //   const oData = await Core.readData(
        //     exportDataModel,
        //     '/DownloadExcel',
        //     aExportFilters
        //   );

        //   if (oData && oData.results && oData.results.length > 0) {
        //     const oDownloadData = oData.results[0];
        //     if (oDownloadData.DownloadFileContentBinary) {
        //       Core.fnDownloadFile(oDownloadData,formname);
        //       if (this._oExportDataDialog) {
        //         this._oExportDataDialog.then(function (oDialog) {
        //           oDialog.close();
        //         });
        //       }
        //     } else {
        //       MessageBox.information("No data found for export");
        //     }
        //   } else {
        //     MessageBox.information("No data found");
        //   }
        // } catch (oError) {
        //   if (oError && oError.message) {
        //     console.error(
        //       "Error reading data:",
        //       oError.message ?? oError.stack
        //     );
        //   }
        //   MessageBox.error(Core.getGeneralTechnicalIssueMsg());
        // }
      },

      _postData: async function (sBase64) {
        try {
          Core.showBusy();
          const exportDataModel = this.getModel("uploadExcelSrv"); 
          let oEntry = new JSONModel({
            TEMPLATE_NAME: this.templateUploadName,
            FILE_NAME: this.sFileName,
            BINARY_DATA: sBase64,
            ToMessageReturnSet: [],
          });
  
          new Promise( 
            function (resolve, reject) { 
              exportDataModel.create("/ExcelFileSet", oEntry.oData, {
                method: "POST",
                success: function (oData) {
                  Core.hideBusy();
                  if (oData && oData.ToMessageReturnSet && oData.ToMessageReturnSet.results.length > 0) {
                    let finalfilter = "";
                    for (let i = 0; i < oData.ToMessageReturnSet.results.length; i++) {
                      const oMessage = oData.ToMessageReturnSet.results[i];
                      if (oMessage.ZZSTATUS === "-") {
                        MessageBox.error(oMessage.ZZMESSAGE);
                      } else {
                        // let oListReportModel = this._oListReport.getModel();
                        
                        let oALV = [];
                        const currentVariantId = this._oFilterBar.getCurrentVariantId();
                        const oFile_UploadController = this._oFilterBar.getControlByKey("ZZIDFILE_UPLOAD");
                        const oDate_UploadController = this._oFilterBar.getControlByKey("ZZDATE_UPLOAD");
                        const oTime_UploadController = this._oFilterBar.getControlByKey("ZZTIME_UPLOAD");

                        // for (let j = 0; j < oData.ToMessageReturnSet.results.length; j++) {
                        //   let oMessageReturn = oData.ToMessageReturnSet.results[j];

                          // oALV.push( new JSONModel({  
                          //   Status: oMessageReturn.ZZSTATUS,
                          //   ZZID_PR: oMessageReturn.ZZID_PR,
                          //   ZZSHEET: oMessageReturn.ZZSHEET,
                          //   ZZMESSAGE: oMessageReturn.ZZMESSAGE,
                          //   BANFN: oMessageReturn.BANFN,
                          //   ZZIDFILE_UPLOAD: oMessageReturn.ZZIDFILE_UPLOAD,
                          //   ZZDATE_UPLOAD: oMessageReturn.ZZDATE_UPLOAD,
                          //   Currency: "",
                          //   CreditLimit: 0,
                          // }) );
                        // }
                        
                        if (currentVariantId == "" || currentVariantId == "standard") {
                          let aDefaultTokens = [];
                          aDefaultTokens.push(
                            new Token({
                              key: oMessage.ZZIDFILE_UPLOAD,
                            })
                          );
                          oFile_UploadController.setTokens(aDefaultTokens);

                          aDefaultTokens = [];
                          aDefaultTokens.push(
                            new Token({
                              key: oMessage.ZZDATE_UPLOAD,
                            })
                          );
                          oDate_UploadController.setTokens(aDefaultTokens);

                          aDefaultTokens = [];
                          aDefaultTokens.push(
                            new Token({
                              key: oMessage.ZZTIME_UPLOAD,
                            })
                          );
                          oTime_UploadController.setTokens(aDefaultTokens);
                        } 

                        finalfilter = "ZZIDFILE_UPLOAD eq '" + oMessage.ZZIDFILE_UPLOAD + "'" + " and ZZDATE_UPLOAD eq '" + oMessage.ZZDATE_UPLOAD + "'" + " and ZZID_PR eq '" + oMessage.ZZID_PR + "'";
                        
                        let oTable = this._oListReport.getTable();
                        // oTable.setModel(oALV, "");
                        oTable.bindRows({
                          path: "/PUR01",
                          parameters: {
                            $filter: finalfilter,
                          }
                        });
                        
                        // this.aFiles = [];

                        this._oListReport.rebindTable();
                                              
                      }
                    }

                        // this._oTable.getModel("local").setProperty("/items", oALV);

                        // this._oListReport.setModel(oALV,"");
                        




                        // let oBinding = this._oTable.getBinding("rows"); // 'rows' for AnalyticalTable
                        // if (oBinding) {
                        //   // oBinding.setModel(oALV,"");
                        //   // oBinding.rebindTable();
                        //   oBinding.refresh();
                        // }    

                        // oListReportModel.oData.results = oALV;
                        // oListReportModel.refresh(true);


                    resolve(oData);
                  } else {
                    MessageBox.information("No data found");
                  }
                }.bind(this),
                error: function (oError) {
                  this.hideBusy();
                  reject(oError);
                }.bind(this),
              });
          }.bind(this));
        } catch (error) {
          if (oError && oError.message) {
            console.error(
              "Error reading data:",
              oError.message ?? oError.stack
            );
          }
          MessageBox.error(Core.getGeneralTechnicalIssueMsg());
        } 
      },          
      /**
       * Convenience method for getting model.
       * @public
       * @returns {Object} the object model
       */
      getModel: function (sName) {
        return this.getView().getModel(sName);
      },

      /**
       * Convenience method for accessing the router.
       * @public
       * @returns {Object} the object model
       */
      setModel: function (oModel, sName) {
        return this.getView().setModel(oModel, sName);
      },
      onBeforeRendering: function () {},
      //EOF
    };
  }
);
