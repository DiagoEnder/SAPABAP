sap.ui.define(
    [
        "sap/ui/core/format/DateFormat",
        "sap/ui/model/json/JSONModel",
        "sap/m/MessageBox"
    ],
    function (DateFormat, JSONModel, MessageBox) {
        "use strict";
        const DATE_FORMAT_TIME_PATTERN = "yyyy/MM/dd HH:mm:ss";
        return {
            DEFAULT_CONVERSION_ROUTINE: 0,
            FIXED_FLOAT_NUMBER: 3,
            LOG_INFO: "I",
            LOG_ERROR: "E",
            /**
             *
             * @param aSources - Source array want to sort
             * @sortType - accept: ASC, DESC
             * @sortColumn - name of column in array
             * @bFillterNullSortColValue - default is false accept: true, false
             * @returns - sorted array
             * */
            fnSortArrayObject: function (
                aSources,
                sortType,
                sortColumn,
                bFilterNullSortColValue = false
            ) {
                if (!aSources || aSources === undefined) {
                    //@ts-ignore
                    console.error(
                        "UICommon - fnSortArrayObject - Invalid Source: ",
                        aSources
                    );
                    return [];
                }
                // Remove objects with null value for sortColumn
                if (bFilterNullSortColValue) {
                    aSources = aSources.filter((item) => item[sortColumn] !== null);
                }

                // Sort the array based on sortColumn and sortType
                aSources.sort((a, b) => {
                    if (sortType === "ASC") {
                        return a[sortColumn] - b[sortColumn];
                    } else if (sortType === "DESC") {
                        return b[sortColumn] - a[sortColumn];
                    }
                    //@ts-ignore
                    console.error(
                        "UICommon - fnSortArrayObject - Invalid Sort Type: ",
                        sortType
                    );
                    return [];
                });

                return aSources;
            },
            fnHandleResponseException: function (error) {
                let oError = error.responseJSON;
                let sMessage = "";
                if (!oError) {
                    sMessage = "Request Failed"; //should return common message by i18n
                } else {
                    //handle basic error
                    if (oError.message) {
                        sMessage = oError.message || error.responseText;
                    }
                    //handle custom error
                    if (oError.data) {
                        if (oError.data.message) {
                            sMessage = sMessage + " " + oError.data.message;
                        }
                    }
                    //handle odata error
                    if (sMessage === "") {
                        if (oError.error) {
                            sMessage = oError.error.message;
                        }
                    }
                    //@ts-ignore
                    console.error(
                        "UICommon - fnHandleResponseException - error: ",
                        JSON.stringify(oError.data ? oError.data.stack : oError.message)
                    );
                }
                return sMessage;
            },
            fnGetCurrDateByFormat: function (sFormatPattern = "yyyy-MM-dd") {
                try {
                    let sCurrDate = new Date();
                    const DateFormatter = DateFormat.getDateInstance({
                        pattern: sFormatPattern,
                    });
                    return DateFormatter.format(sCurrDate);
                } catch (error) {
                    //@ts-ignore
                    console.error("UICommon - fnGetCurrDateByFormat - error: ", error);
                }
            },
            fnIsZeroValue: function (sValue) {
                if (sValue === "0" || sValue === 0) {
                    return true;
                }
                return false;
            },
            fnFindObjectInArray: function (array, property, value) {
                if (!array || !property || !value) {
                    return null;
                }
                return array.find((obj) => obj[property] === value);
            },
            /**
             * Initialize Global Model and add object to it
             * @param {Object} oDataToBeAdded
             * @param {string} sNameToBeAdded
             * @return: void
             * */
            fnMaintainGlobalModelData: function (oDataToBeAdded, sNameToBeAdded) {
                let oGlobalModel = sap.ui.getCore().getModel("global");
                let oGlobalData;
                if (!oGlobalModel) {
                    oGlobalModel = new JSONModel();
                    oGlobalData = {};
                } else {
                    //@ts-ignore
                    oGlobalData = oGlobalModel.getData();
                }

                oGlobalData[sNameToBeAdded] = oDataToBeAdded;
                //@ts-ignore
                oGlobalModel.setData(oGlobalData);
                sap.ui.getCore().setModel(oGlobalModel, "global");
            },
            fnIsValidJSON: function (jsonString) {
                try {
                    JSON.parse(jsonString);
                    return true;
                } catch (error) {
                    //@ts-ignore
                    console.error("UICommon - fnIsValidJSON - error: ", error);
                    return false;
                }
            },
            fnIsDevEnv: function () {
                //@ts-ignore
                const sOriginUri = window.location.origin;
                const sDevIde = "localhost";
                if (sOriginUri.includes(sDevIde)) {
                    return true;
                }
                return false;
            },
            fnGenUUID: function (version = 4) {
                return crypto.randomUUID(); //for now by default v4
            },
            fnShowTechnicalIssue: function () {
                const sGeneralMsg =
                    "Something went wrong. Please get in touch with the Technical team for support!";
                MessageBox.error(sGeneralMsg);
            },
            /**
             *
             * @param {*} sDateRaw: String of datetime
             * @returns formated DateTime
             */
            fnDisplayDateAndTime: function (sDateRaw) {
                try {
                    if (sDateRaw) {
                        const inputDate = new Date(sDateRaw);

                        // Extract date components
                        const year = inputDate.getFullYear() % 100; // Get the last two digits of the year
                        const month = inputDate.getMonth() + 1; // Months are zero-based, so add 1
                        const day = inputDate.getDate();
                        const hours = inputDate.getHours();
                        const minutes = inputDate.getMinutes();

                        // Determine AM or PM
                        const amOrPm = hours >= 12 ? "PM" : "AM";

                        // Convert hours to 12-hour format
                        const formattedHours = hours % 12 || 12; // '0' should be displayed as '12'

                        // Pad single-digit day and month with leading zeros
                        const formattedMonth = month.toString().padStart(2, "0");
                        const formattedDay = day.toString().padStart(2, "0");

                        // Format the date string
                        const formattedDateString = `${formattedMonth}/${formattedDay}/${year} at ${formattedHours}:${minutes
                            .toString()
                            .padStart(2, "0")} ${amOrPm}`;
                        if (new Date(formattedDateString) instanceof Date) {
                            return formattedDateString;
                        } else {
                            return "";
                        }
                    }
                    return "";
                } catch (error) {
                    //@ts-ignore
                    console.error("UICommon - fnDisplayDateAndTime - error: ", error);
                    return "Parse Date Failed";
                }
            },
            /**
             * @param {Object} oSourceObject
             * @param {String} value
             */
            fnGetKeyByValue(oSourceObject, value) {
                try {
                    return Object.keys(oSourceObject).find(
                        (key) => oSourceObject[key] === value
                    );
                } catch (error) {
                    //@ts-ignore
                    console.error(`UICommon - fnGetKeyByValue - error: ${error}`);
                    return "";
                }
            },
            /**
             *
             * @param {*} logs
             * @param {String} sType
             * @param {String} sLogSource
             */
            log: function (logs, sType = this.LOG_INFO, sLogSource) {
                let logMsg = logs;

                if (sLogSource) {
                    logMsg = `${logs}${sLogSource}`;
                }

                if (sType === this.LOG_INFO) {
                    //@ts-ignore
                    console.log(logMsg);
                }

                if (sType === this.LOG_ERROR) {
                    //@ts-ignore
                    console.error(logMsg);
                }
            },
            /**
             *
             * @param {*} logs
             * @param {String} sType
             * @param {String} sLogSource
             */
            devLog: function (logs, sType = this.LOG_INFO, sLogSource) {
                if (!this.fnIsDevEnv()) {
                    return;
                }

                this.log(logs, sType, sLogSource);
            },
            fnGetDeviceData: function () {
                const oDeviceModel = sap.ui.getCore().getModel("device");
                if (oDeviceModel) {
                    //@ts-ignore
                    return oDeviceModel.getData();
                }
            },
            fnIsDesktop: function () {
                const oDeviceData = this.fnGetDeviceData();
                return oDeviceData.system.desktop;
            },
            fnIsTablet: function () {
                const oDeviceData = this.fnGetDeviceData();
                return oDeviceData.system.tablet;
            },
            fnIsMobile: function () {
                const oDeviceData = this.fnGetDeviceData();
                return oDeviceData.system.phone;
            },
            fnGetTableDataListsFlexible: function (oTable) {
                try {
                    let aDataLists = [];
                    if (!oTable.getBinding("rows") && !oTable.getBinding("items")) {
                        //@ts-ignore
                        console.error(
                            "UICommon - fnGetTableDataListsFlexible - Err: Table i not bound"
                        );
                        return aDataLists;
                    }
                    if (oTable.getBinding("rows")) {
                        aDataLists = oTable.getRows();
                    }
                    if (oTable.getBinding("items")) {
                        aDataLists = oTable.getItems();
                    }
                    //TODO handle other binding later
                    return aDataLists;
                } catch (error) {
                    //@ts-ignore
                    console.error(
                        "UICommon - fnGetTableDataListsFlexible - Err: ",
                        error
                    );
                    return [];
                }
            },
            fnGetTableSingleDataFlexible: function (oLine, oController) {
                try {
                    //for now we're know that on Desktop binding using sap.ui.table.Table and for tablet/mobile we're using  sap.m.Table
                    if (this.fnIsDesktop()) {
                        if (oLine.getRowBindingContext()) {
                            return oLine.getRowBindingContext().getObject();
                        }
                        return null;
                    }
                    if (this.fnIsTablet() || this.fnIsMobile()) {
                        const oModel = oController.getModel(oLine.getModel());
                        return oModel.getProperty(oLine.getBindingContextPath());
                    }
                    //@ts-ignore
                    console.error(
                        "UICommon - fnGetTableSingleDataFlexible - Err: Line item not bound, cannot get data"
                    );
                    return null;
                } catch (error) {
                    //@ts-ignore
                    console.error(
                        "UICommon - fnGetTableSingleDataFlexible - Err: ",
                        error
                    );
                    return null;
                }
            },
            /**
             * Removes text that appears after a special character in the provided file name.
             *
             * @param {string} originalFileName - The original file name to be modified.
             * @returns {string} - The cleaned file name with text after the special character removed.
             */
            fnRemoveTextAfterSpecialCharacter: function (originalFileName) {
                const pattern = /[!@#$%^&*()_+={}\[\]:";'<>?,./\\|`~].*/;
                const cleanedFileName = originalFileName.replace(pattern, "");
                return cleanedFileName;
            },
            /**
             * Constructs an OData filter string URL based on an array of filter objects.
             * #kiennt: refactor later! the filter model is currently inconsistent.
             *
             * @param {Array} aFilters - An array of filter objects.
             * @returns {string} - The constructed OData filter string URL.
             */
            fnBuildODataFilterStringUrl: function (aFilters) {
                let filterExpressions = [];

                if (!aFilters) {
                    return;
                }

                for (const filter of aFilters) {
                    let filterExpression;

                    if (filter[0] === undefined) {
                        if (
                            filter.sPath === "activityTypeId" ||
                            filter.sPath === "isActive"
                        ) {
                            filterExpression = `${filter.sPath
                                } ${filter.sOperator.toLowerCase()} ${filter.oValue1}`;
                        } else if (
                            filter.sOperator &&
                            filter.sOperator.toLowerCase() === "contains"
                        ) {
                            filterExpression = `contains(${filter.sPath}, '${filter.oValue1}')`;
                        } else {
                            filterExpression =
                                filter.sOperator.toLowerCase() === "bt"
                                    ? `${filter.sPath} ge ${filter.oValue1} and ${filter.sPath} le ${filter.oValue2}`
                                    : `${filter.sPath} ${filter.sOperator.toLowerCase()} '${filter.oValue1
                                    }'`;
                        }
                    } else {
                        const tempFilterExpressions = filter.map((filterValue) => {
                            let sValue1 = "";
                            let sPath = filterValue.sPath;
                            let sOperator = filterValue.sOperator.toLowerCase();

                            if (sOperator == "contains") {
                                return `contains(${filterValue.sPath}, '${filterValue.oValue1}')`;
                            } else if (
                                filterValue.sPath === "legalRiskTypes" &&
                                filterValue.oCondition != null
                            ) {
                                const oCondition = filterValue.oCondition;
                                sValue1 = `'${oCondition.oValue1}')`;
                                sPath = "legalRiskTypes/any(d:d/fieldValue";
                                sOperator = oCondition.sOperator.toLowerCase();
                            } else if (
                                filterValue.sPath === "activityTypeId" ||
                                filterValue.sPath === "activityNo" ||
                                filterValue.sPath === "ID" ||
                                filterValue.sPath === "isFavorite "
                            ) {
                                sValue1 = filterValue.oValue1;
                            } else {
                                sValue1 = `'${filterValue.oValue1}'`;
                            }
                            return `${sPath} ${sOperator} ${sValue1}`;
                        });

                        filterExpression = `(${tempFilterExpressions.join(" or ")})`;
                    }

                    filterExpressions.push(filterExpression);
                }

                const filterString = filterExpressions.join(" and ");
                const sResultFilters =
                    filterExpressions.length > 0 ? `$filter=${filterString}` : "";

                return sResultFilters;
            },
            /**
             *
             * @param {Object} oSourceObj
             * @param {int} iLevel
             * @param {Array} aExcludes list of prop will NOT exist on oClonedObj object
             * @returns {Object}
             */
            fnDeepCloneByLevel: function (oSourceObj, iLevel = 0, aExcludes = []) {
                try {
                    if (iLevel === 0) {
                        // If iLevel is 0, return a shallow clone of the object
                        const oClonedObj = { ...oSourceObj };
                        aExcludes.forEach((key) => delete oClonedObj[key]);
                        return oClonedObj;
                    }

                    if (typeof oSourceObj !== "object" || oSourceObj === null) {
                        // If oSourceObj is not an object or is null, return it as is
                        return oSourceObj;
                    }

                    if (Array.isArray(oSourceObj)) {
                        // If oSourceObj is an array, deep clone each element
                        return oSourceObj.map((item) =>
                            this.fnDeepCloneByLevel(item, iLevel - 1, aExcludes)
                        );
                    }

                    // If oSourceObj is an object, deep clone its properties
                    const oClonedObj = {};
                    for (const key in oSourceObj) {
                        if (
                            Object.hasOwnProperty.call(oSourceObj, key) &&
                            !aExcludes.includes(key)
                        ) {
                            oClonedObj[key] = this.fnDeepCloneByLevel(
                                oSourceObj[key],
                                iLevel - 1,
                                aExcludes
                            );
                        }
                    }
                    return oClonedObj;
                } catch (error) {
                    //@ts-ignore
                    console.error("UICommon - fnDeepCloneByLevel - Err: ", error);
                    return { ...oSourceObj };
                }
            },
            fnGetQueryParams: function (url) {
                try {
                    const queryParams = {};
                    const urlParts = url.split("?");
                    if (urlParts.length > 1) {
                        const paramString = urlParts[1];
                        const paramPairs = paramString.split("&");
                        for (const paramPair of paramPairs) {
                            const [key, value] = paramPair.split("=");
                            queryParams[key] = decodeURIComponent(value);
                        }
                    }
                    return queryParams;
                } catch (error) {
                    //@ts-ignore
                    console.error("UICommon - fnGetQueryParams - Err: ", error);
                    return [];
                }
            },
            fnGetForceRoleValue: function () {
                try {
                    //@ts-ignore
                    const sOriginUri = window.location.href;
                    const queryParams = this.fnGetQueryParams(sOriginUri);
                    const forceRole = queryParams["forceRole"];
                    if (forceRole) {
                        return forceRole.split("/")[0];
                    }

                    return null;
                } catch (error) {
                    //@ts-ignore
                    console.error("UICommon - fnGetForceRoleValue - Err: ", error);
                    return null;
                }
            },
            /**
             * @param {Array} aSources
             * @param {Object} oNewItem
             * @param {Number} iTargetPosition
             * @param {String} sKey
             * @param {Boolean} bAddBefore //true;false
             * @param {String} sortOrder //ASC;DESC
             */
            fnAddObjectToArrayDynamic: function (
                aSources,
                oNewItem,
                iTargetPosition,
                sKey,
                bAddBefore = true,
                sortOrder = "ASC"
            ) {
                try {
                    let aFinal = [...aSources];

                    //Update the position of the new item based on whether it should be added before or after
                    let iPosTemp = iTargetPosition;
                    if (bAddBefore) {
                        oNewItem[sKey] = iTargetPosition;
                    } else {
                        oNewItem[sKey] = iTargetPosition + 1;
                        iPosTemp = iTargetPosition + 1;
                    }

                    //Adjust the positions of existing items accordingly
                    aFinal.forEach((item) => {
                        if (bAddBefore) {
                            if (item[sKey] >= iTargetPosition) {
                                item[sKey]++;
                            }
                        } else {
                            if (item[sKey] > iTargetPosition) {
                                iPosTemp++;
                                item[sKey] = iPosTemp;
                            }
                        }
                    });
                    aFinal.push(oNewItem);

                    // Sort [sKey] based on sortOrder
                    if (sortOrder === "ASC") {
                        aFinal.sort((a, b) => a[sKey] - b[sKey]);
                    } else if (sortOrder === "DESC") {
                        aFinal.sort((a, b) => b[sKey] - a[sKey]);
                    }
                    // console.log("Final Array",JSON.stringify(aFinal));
                    return aFinal;
                } catch (error) {
                    //@ts-ignore
                    console.error("UICommon - fnAddObjectToArrayDynamic - Err: ", error);
                    return aSources;
                }
            },

            /**
             *
             * @param {*} sDateRaw: String of datetime
             * @returns formated DateTime
             */
            fnDisplayDate: function (sDateRaw) {
                try {
                    const inputDate = new Date(sDateRaw);

                    // Extract date components
                    const year = inputDate.getUTCFullYear();
                    const month = inputDate.getMonth() + 1; // Months are zero-based, so add 1
                    const day = inputDate.getDate();

                    // Pad single-digit day and month with leading zeros
                    const formattedMonth = month.toString().padStart(2, "0");
                    const formattedDay = day.toString().padStart(2, "0");

                    // Format the date string
                    const formattedDateString = `${formattedMonth}/${formattedDay}/${year}`;

                    return formattedDateString;
                } catch (error) {
                    //@ts-ignore
                    console.error("UICommon - fnDisplayDate - error: ", error);
                    return "Parse Date Failed";
                }
            },
            fnGetRouteByHash: function (sRouteHash) {
                try {
                    const aHashParts = sRouteHash.split("/");
                    let sRouteName = aHashParts[0];
                    sRouteName = sRouteName.split("?")[0];
                    sRouteName = sRouteName.split("(")[0];
                    return sRouteName;
                } catch (error) {
                    //@ts-ignore
                    console.error("UICommon - fnGetRouteNameByHash - Err: ", error);
                    return "";
                }
            },
            fnTransformCorresponding: function (
                aMapping,
                oSource,
                oTarget,
                bReturn = false
            ) {
                let oResponse = { ...oSource };
                aMapping.forEach((oMapping) => {
                    oSource[oMapping.source] = oTarget[oMapping.target];
                    oResponse[oMapping.source] = oTarget[oMapping.target];
                });
                if (bReturn) {
                    return oResponse;
                }
            },
            fnRemoveLeadingZeros(inputString) {
                // Parse the string to remove leading zeros
                if (!inputString) {
                    return "";
                } else {
                    let result = parseInt(inputString).toString();
                    return result;
                }
            },
            /**
             * Generates an OData URL filter string based on an array of filter objects.
             * Each filter object contains the column name, operation, field value, and data type.
             * @param {Array} filterArray - An array of filter objects.
             * @returns {string} - The generated OData URL filter string.
             */
            fnGenerateODataFilter: function (filterArray) {
                // Check if the input is an array and if it's empty
                if (!Array.isArray(filterArray) || filterArray.length === 0) {
                    return ""; // Return an empty string if the input is not valid
                }

                // Map over the filterArray to generate filter expressions for each filter object
                const filters = filterArray
                    .map((filter) => {
                        const { fieldName, operation, fieldValue, dataType } = filter;
                        // Check if any of the required fields are missing
                        if (
                            !fieldName ||
                            !operation ||
                            fieldValue === undefined ||
                            dataType === undefined
                        ) {
                            return ""; // Skip this filter object if any required field is missing
                        }
                        // Convert the field value to the appropriate format based on the data type
                        let formattedValue = fieldValue;
                        if (dataType === "string") {
                            formattedValue = `'${fieldValue}'`;
                        }
                        // Return the filter expression for this filter object
                        return `${fieldName} ${operation} ${formattedValue}`;
                    })
                    .filter((filter) => filter !== ""); // Filter out empty filter expressions

                // Join the filter expressions with 'and' and wrap them with $filter=
                return filters.length > 0 ? `$filter=${filters.join(" and ")}` : ""; // Return the final OData filter string
            },

            /**
             *
             * @param {*} sDateRaw: String of datetime
             * @returns formated DateTime
             */
            fnDisplayDateByUTC: function (sDateRaw) {
                try {
                    const inputDate = new Date(sDateRaw);

                    // Extract date components
                    const year = inputDate.getUTCFullYear();
                    const month = inputDate.getUTCMonth() + 1; // Months are zero-based, so add 1
                    const day = inputDate.getUTCDate();

                    // Pad single-digit day and month with leading zeros
                    const formattedMonth = month.toString().padStart(2, "0");
                    const formattedDay = day.toString().padStart(2, "0");

                    // Format the date string
                    const formattedDateString = `${formattedMonth}/${formattedDay}/${year}`;

                    return formattedDateString;
                } catch (error) {
                    //@ts-ignore
                    console.error("UICommon - fnDisplayDateByUTC - error: ", error);
                    return "Parse Date Failed";
                }
            },
            /**
             * Convert time to end of day 00:00:00
             * @param: oDate
             * @return oDate with time end of day
             * @last modified: Tinh Leo
             * */
            fnToStartDay: function (oDate) {
                try {
                    let startOfDayDate = new Date(
                        oDate.getFullYear(),
                        oDate.getMonth(),
                        oDate.getDate()
                    );
                    startOfDayDate.setHours(0, 0, 0, 0);
                    return startOfDayDate;
                } catch (error) {
                    console.log(`UICommon - fnToStartDay - Error: ${error}`);
                    return null;
                }
            },
            /**
             * Convert time to end of day 23:59:59
             * @param: oDate
             * @return oDate with time end of day
             * @last modified: Tinh Leo
             * */
            fnToEndDay: function (oDate) {
                try {
                    let endOfDayDate = new Date(
                        oDate.getFullYear(),
                        oDate.getMonth(),
                        oDate.getDate()
                    );
                    endOfDayDate.setHours(23, 59, 59, 999);
                    return endOfDayDate;
                } catch (error) {
                    console.log(`UICommon - fnToEndDay - Error: ${error}`);
                    return null;
                }
            },
            fnGetIsoStartDayAsString: function (oDate) {
                try {
                    oDate.setUTCHours(0, 0, 0, 0);
                    const isoDateStartDayString = oDate.toISOString();
                    return isoDateStartDayString;
                } catch (error) {
                    console.log(`UICommon - fnDateToIsoStartDay - Error: ${error}`);
                    return null;
                }
            },
            fnGetIsoEndDayAsString: function (oDate) {
                try {
                    oDate.setUTCHours(0, 0, 0, 0);
                    oDate.setDate(oDate.getDate() + 1);
                    oDate.setMilliseconds(oDate.getMilliseconds() - 1);
                    const isoDateStartDayString = oDate.toISOString();
                    return isoDateStartDayString;
                } catch (error) {
                    console.log(`UICommon - fnDateToIsoStartDay - Error: ${error}`);
                    return null;
                }
            },
            /**
             *
             * @param {*} timeZoneOffset
             * @returns
             */
            fnGetDateStringFormatAsUtcOffset: function (
                date,
                formatPattern = DATE_FORMAT_TIME_PATTERN,
                timeZoneOffset = -120, //Offset in minutes (negative because it's UTC+2)
            ) {
                try {
                    let adjustedDate = new Date(date.getTime() + timeZoneOffset * 60000);

                    // Create a date formatter with the desired time zone
                    let formatter = sap.ui.core.format.DateFormat.getDateTimeInstance({
                        pattern: formatPattern,
                        UTC: true,
                    });

                    // Format the date with the desired time zone
                    let formattedDate = formatter.format(adjustedDate);
                    return formattedDate;
                } catch (error) {
                    console.log(`UICommon - fnDateToIsoStartDay - Error: ${error}`);
                    return null;
                }
            },
            fnGetCurrDateStringFormatAsUtcOffset: function () {
                try {
                    let date = new Date();
                    return this.fnGetDateStringFormatAsUtcOffset(date);
                } catch (error) {
                    console.log(`UICommon - fnDateToIsoStartDay - Error: ${error}`);
                    return null;
                }
            },
            /**
             *
             * @param {*} sDateRaw: String of datetime
             * @returns formated DateTime
             */
            fnDisplayYearMonthDay: function (sDateRaw) {
                try {
                    if (!sDateRaw) {
                        return;
                    }

                    const inputDate = new Date(sDateRaw);

                    // Extract date components
                    const year = inputDate.getUTCFullYear();
                    const month = inputDate.getMonth() + 1; // Months are zero-based, so add 1
                    const day = inputDate.getDate();

                    // Pad single-digit day and month with leading zeros
                    const formattedMonth = month.toString().padStart(2, "0");
                    const formattedDay = day.toString().padStart(2, "0");

                    // Format the date string
                    const formattedDateString = `${year}/${formattedMonth}/${formattedDay}`;

                    return formattedDateString;
                } catch (error) {
                    //@ts-ignore
                    console.error("UICommon - fnDisplayYearMonthDay - error: ", error);
                    return "Parse Date Failed";
                }
            },
            /**
             * Generates a string with leading zeros based on the length of the input number and a standard length.
             *
             * @param {string} sInputNumber - The input number as a string.
             * @param {number} iStandardLength - The standard length of the resulting string with leading zeros.
             * @returns {string} A string with leading zeros based on the input number and standard length.
             */
            fnGenerateLeadingZerosNumber: function (sInputNumber, iStandardLength) {
                // Calculate the number of leading zeros required
                const iNumberOfZeros = iStandardLength - sInputNumber.length;

                // Generate leading zeros
                const sLeadingZeros = "0".repeat(Math.max(0, iNumberOfZeros));

                // Concatenate leading zeros with the input number
                return sLeadingZeros + sInputNumber;
            },
            /**
             * @param {String} num: String or Numner
             * @param {*} size:  Number size
             * @returns formated DateTime
             */
            fnPadNumber: function (num, size) {
                num = num.toString();
                while (num.length < size) num = "0" + num;
                return num;
            },

            /**
             *
             * @param {*} sDateRaw: String of datetime
             * @returns formated DateTime
             */
            fnDisplayUTCDate: function (sDateRaw) {
                if (!sDateRaw) return "";
                try {
                    const inputDate = new Date(sDateRaw);

                    // Extract date components
                    const year = inputDate.getUTCFullYear();
                    const month = inputDate.getUTCMonth() + 1; // Months are zero-based, so add 1
                    const day = inputDate.getUTCDate();

                    // Pad single-digit day and month with leading zeros
                    const formattedMonth = month.toString().padStart(2, "0");
                    const formattedDay = day.toString().padStart(2, "0");

                    // Format the date string
                    const formattedDateString = `${formattedMonth}/${formattedDay}/${year}`;

                    return formattedDateString;
                } catch (error) {
                    //@ts-ignore
                    console.error("UICommon - fnDisplayDate - error: ", error);
                    return "Parse Date Failed";
                }
            },

            /**
             * Converts a given date string to ISO 8601 format ("YYYY-MM-DDTHH:MM:SSZ").
             *
             * @param {string} dateString - The input date string. It can be in different formats, such as
             *                              "Thu Jun 06 2024 07:00:00 GMT+0700 (Indochina Time)" or "2024-06-06T00:00:00Z".
             * @returns {string} - The date string converted to ISO 8601 format ("YYYY-MM-DDTHH:MM:SSZ").
             */
            fnConvertToISO: function (dateString) {
                var date;

                // Ensure the input is a string
                dateString = String(dateString);

                // Check if the input is already in ISO format and ends with 'Z' indicating it's in UTC
                if (!isNaN(Date.parse(dateString)) && dateString.slice(-1) === "Z") {
                    date = new Date(dateString); // Parse the ISO date string to a Date object
                } else {
                    // Parse the input date string to a Date object for other formats
                    date = new Date(dateString);
                }

                // Adjust the date for the timezone offset to get the UTC time
                var utcDate = new Date(
                    date.getTime() - date.getTimezoneOffset() * 60000
                );

                // Convert the adjusted date to the desired ISO string format
                var isoString = utcDate.toISOString();

                // Return the formatted ISO string
                return isoString;
            },
            fnGetCurrDateTimeFilter: function () {
                var oDate = new Date();
                var oDateFormat = sap.ui.core.format.DateFormat.getDateTimeInstance({
                    pattern: "yyyy-MM-dd'T'HH:mm:ss"
                });
                return "datetime'" + oDateFormat.format(oDate) + "'";
            },
            formatDateFilter: function (date) {
                let oDate = new Date(date);
                var oDateFormat = sap.ui.core.format.DateFormat.getDateTimeInstance({
                    pattern: "yyyy-MM-dd'T'HH:mm:ss"
                });
                return "datetime'" + oDateFormat.format(oDate) + "'";

            }
            //EOF
        };
    }
);
