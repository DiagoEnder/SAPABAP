const CORE_IMPORT_MODULE = `zcmmpur01`;
const USER_DEFAULT_SYSTEM_CONTEXT = { id: "" };
sap.ui.define(
  [
    "sap/ui/model/json/JSONModel",
    "sap/m/MessageBox",
    "sap/m/Token",
    `ngs/pvgas/${CORE_IMPORT_MODULE}/ext/common/HttpRequest`,
    `ngs/pvgas/${CORE_IMPORT_MODULE}/ext/common/FilterCommon`,
    `ngs/pvgas/${CORE_IMPORT_MODULE}/ext/common/UICommon`,
    "sap/m/Menu",
    "sap/m/MenuItem",
    "sap/m/MenuButton",
  ],
  function (JSONModel, MessageBox, Token, HttpRequest, FilterCommon, UICommon, Menu, MenuItem, MenuButton) {
    "use strict";
    const LIST_REPORT_NAMESPACE =
      "sap.suite.ui.generic.template.ListReport.view.ListReport";
    return {
      fnGetViewControl: function (
        oController,
        sComponentId = "responsiveTable"
      ) {
        try {
          //sTableType: TreeTable; responsiveTable; analyticalTable; gridTable; table; listReport; listReportFilter
          //should be get sTableType from manifest configuration
          const sControlId = `${oController
            .getView()
            .getId()}--${sComponentId}`;
          const oControl = oController.getView().byId(sControlId);
          if (!oControl) {
            console.log("Control not found");
            return null;
          }
          return oControl;
        } catch (error) {
          console.log("Error in fnGetViewControl: " + error);
          return null;
        }
      },
      //Export handler
      /**
       * Please define two function onExportDataHandler in your controller
       * @param {*} oController
       * @returns
       */
      fnAddExportMenuButtonToSmartTableToolbar: function (
        oController,
        fnExportCallback
      ) {
        if (!oController) {
          console.clear();
          console.log(
            `fnAddExportMenuButtonToSmartTableToolbar - Missing oController`
          );
          MessageBox.error(this.getGeneralTechnicalIssueMsg());
        }
        this.extListReportController = oController;
        this._exportCallback = fnExportCallback;
        try {
          const oToolbar = oController._oListReport._oToolbar;
          if (!oToolbar) {
            return;
          }
          // Find the TablePersonalisation button
          const aToolbarContent = oToolbar.getContent();
          let iPersonalizationBtnIndex = -1;

          aToolbarContent.forEach(function (oControl, index) {
            if (
              oControl.getMetadata().getName() === "sap.m.Button" &&
              oControl.getIcon() === "sap-icon://action-settings"
            ) {
              iPersonalizationBtnIndex = index;
            }
          });

          let oResourceBundle = oController
          .getOwnerComponent()
          .getModel("i18n")
          .getResourceBundle();

          let arrButton = this.fnGetListTemplate().map(function (key) {
            return oResourceBundle.getText(key);
          });

          // let arrButton = [
          //   "TemplateFirst",
          //   "TemplateSecond",
          // ].map(function (key) {
          //   return oResourceBundle.getText(key);
          // });

          let MenuItems = arrButton.map(
            (item, sIndex) =>
              new MenuItem({
                text: item,
                press: this._fnOnExportDataHandler.bind(this, sIndex + 1),
              })
          );

          let oMenuButton = new MenuButton({
            id: "ngs.pvgas.zcmmpur01.MenuDownload",
            text: "{i18n>DownloadTemplateBtn}",
            buttonMode: sap.m.MenuButtonMode.Regular,
            useDefaultActionOnly: true,
            width: "auto",
            menu: new Menu({
              items: MenuItems,
            }),
          });

          if (iPersonalizationBtnIndex !== -1) {
            oToolbar.insertContent(oMenuButton, iPersonalizationBtnIndex + 1);
          } else {
            // If personalization button not found, add to end of toolbar
            oToolbar.addContent(oMenuButton);
          }

          // //Create Export Excel Button
          // let oButton = new sap.m.Button({
          //   text: "{i18n>DownloadTemplateBtn}",
          //   press: this._fnOnExportDataHandler.bind(this),
          //   customData: [
          //     new sap.ui.core.CustomData({
          //       key: "outputType",
          //       value: "1",
          //     }),
          //   ],
          // });

          // if (iPersonalizationBtnIndex !== -1) {
          //   oToolbar.insertContent(oButton, iPersonalizationBtnIndex + 1);
          // } else {
          //   // If personalization button not found, add to end of toolbar
          //   oToolbar.addContent(oButton);
          // }
        } catch (error) {
          console.clear();
          console.log(
            `fnAddExportMenuButtonToSmartTableToolbar error: ${error.stack}`
          );
          MessageBox.error(this.getGeneralTechnicalIssueMsg());
        }
      },

      _fnOnExportDataHandler: function (oEvent) {
        // const oButton = oEvent.getSource();
        // const oCustomData = oButton.getCustomData();
        // const oOutputType = oCustomData.find(
        //   (oData) => oData.getKey() === "outputType"
        // );
        // if (!oOutputType) {
        //   MessageBox.error(this.getGeneralTechnicalIssueMsg());
        //   return;
        // }
        // const sOutputType = oOutputType.getValue();
        if (this._exportCallback) {
          this._exportCallback(oEvent);
        } else {
          MessageBox.error(this.getGeneralTechnicalIssueMsg());
        }
      },

      // _fnOnExportDataHandler: function (oEvent) {
      //   const oButton = oEvent.getSource();
      //   const oCustomData = oButton.getCustomData();
      //   const oOutputType = oCustomData.find(
      //     (oData) => oData.getKey() === "outputType"
      //   );
      //   if (!oOutputType) {
      //     MessageBox.error(this.getGeneralTechnicalIssueMsg());
      //     return;
      //   }
      //   const sOutputType = oOutputType.getValue();
      //   if (this._exportCallback) {
      //     this._exportCallback(sOutputType);
      //   } else {
      //     MessageBox.error(this.getGeneralTechnicalIssueMsg());
      //   }
      // },

      fnAddUploadMenuButtonToSmartTableToolbar: function (
        oController,
        fnUploadCallback
      ) {
        if (!oController) {
          console.clear();
          console.log(
            `fnAddUploadMenuButtonToSmartTableToolbar - Missing oController`
          );
          MessageBox.error(this.getGeneralTechnicalIssueMsg());
        }
        this.extListReportControllerUpload = oController;
        this._uploadCallback = fnUploadCallback;
        try {
          const oToolbar = oController._oListReport._oToolbar;
          if (!oToolbar) {
            return;
          }
          // Find the TablePersonalisation button
          const aToolbarContent = oToolbar.getContent();
          let iPersonalizationBtnIndex = -1;

          aToolbarContent.forEach(function (oControl, index) {
            if (
              oControl.getMetadata().getName() === "sap.m.Button" &&
              oControl.getIcon() === "sap-icon://action-settings"
            ) {
              iPersonalizationBtnIndex = index;
            }
          });

          let oResourceBundle = oController
          .getOwnerComponent()
          .getModel("i18n")
          .getResourceBundle();

          let arrButton = this.fnGetListTemplate().map(function (key) {
            return oResourceBundle.getText(key);
          });

          // let arrButton = [
          //   "TemplateFirst",
          //   "TemplateSecond",
          // ].map(function (key) {
          //   return oResourceBundle.getText(key);
          // });

          let MenuItems = arrButton.map(
            (item, sIndex) =>
              new MenuItem({
                text: item,
                press: this._fnOnUploadDataHandler.bind(this, sIndex + 1),
              })
          );

          let oMenuButton = new MenuButton({
            id: "ngs.pvgas.zcmmpur01.MenuUpload",
            text: "{i18n>UploadExcelBtn}",
            buttonMode: sap.m.MenuButtonMode.Regular,
            useDefaultActionOnly: true,
            width: "auto",
            menu: new Menu({
              items: MenuItems,
            }),
          });

          if (iPersonalizationBtnIndex !== -1) {
            oToolbar.insertContent(oMenuButton, iPersonalizationBtnIndex + 1);
          } else {
            // If personalization button not found, add to end of toolbar
            oToolbar.addContent(oMenuButton);
          }

          // //Create Export Excel Button
          // let oButton = new sap.m.Button({
          //   text: "{i18n>DownloadTemplateBtn}",
          //   press: this._fnOnExportDataHandler.bind(this),
          //   customData: [
          //     new sap.ui.core.CustomData({
          //       key: "outputType",
          //       value: "1",
          //     }),
          //   ],
          // });

          // if (iPersonalizationBtnIndex !== -1) {
          //   oToolbar.insertContent(oButton, iPersonalizationBtnIndex + 1);
          // } else {
          //   // If personalization button not found, add to end of toolbar
          //   oToolbar.addContent(oButton);
          // }
        } catch (error) {
          console.clear();
          console.log(
            `fnAddUploadMenuButtonToSmartTableToolbar error: ${error.stack}`
          );
          MessageBox.error(this.getGeneralTechnicalIssueMsg());
        }
      },      
      _fnOnUploadDataHandler: function (oEvent) {
        // const oButton = oEvent.getSource();
        // const oCustomData = oButton.getCustomData();
        // const oOutputType = oCustomData.find(
        //   (oData) => oData.getKey() === "outputType"
        // );
        // if (!oOutputType) {
        //   MessageBox.error(this.getGeneralTechnicalIssueMsg());
        //   return;
        // }
        // const sOutputType = oOutputType.getValue();
        if (this._uploadCallback) {
          this._uploadCallback(oEvent);
        } else {
          MessageBox.error(this.getGeneralTechnicalIssueMsg());
        }
      },
      fnGetListTemplate: function(){
        let arrButton = [
          "TemplateFirst",
          "TemplateSecond",
          "TemplateThird",
        ];
        return arrButton;
      },
      fnGetDataFilterQuery: function (oController) {
        try {
          const oExportDataModel = oController._oView.getModel("exportData");
          let oData = oExportDataModel.getData();
          let aQueryParts = [];
          //Leo: Cause of backend naming incorrect
          const mFilterKeyMapping = {
            fileName: "filename",
            outputType: "formattype",
            printDate: "printdate",
          };
          // Loop through object properties and format the query string
          for (let key in oData) {
            if (
              oData.hasOwnProperty(key) &&
              oData[key] !== null &&
              oData[key] !== undefined
            ) {
              let value = oData[key];
              let formattedValue =
                typeof value === "string" ? `'${value}'` : value;
              if (key === "printDate") {
                formattedValue = UICommon.formatDateFilter(value);
              }
              let filterKey = mFilterKeyMapping[key] || key;
              aQueryParts.push(`(${filterKey} eq ${formattedValue})`);
            }
          }
          let sExportFilterQuery = `(${aQueryParts.join(" and ")})`;
          let sFilterBarQuery = this.fnGetFilterQueryString(oController);
          return this.fnCombineFilterQueries(
            sFilterBarQuery,
            sExportFilterQuery
          );
        } catch (error) {
          console.log(`Error in fnGetDataFilterQuery: ${error.stack}`);
          return "";
        }
      },
      fnCombineFilterQueries: function (sFilterBarQuery, sExportFilterQuery) {
        sFilterBarQuery = sFilterBarQuery.trim();
        sExportFilterQuery = sExportFilterQuery.trim();
        if (sFilterBarQuery && sExportFilterQuery) {
          return `(${sFilterBarQuery} and ${sExportFilterQuery})`;
        } else if (sFilterBarQuery) {
          return sFilterBarQuery;
        } else if (sExportFilterQuery) {
          return sExportFilterQuery;
        } else {
          return ""; // Return empty string if both are empty
        }
      },
      fnGetExportFilters: function (oController) {
        let aFilterBarFilters = oController._oFilterBar.getFilters();
        const oExportDataModel = oController._oView.getModel("exportData");
        let oData = oExportDataModel.getData();
        let aExportFilters = [];

        // Filter key mapping for backend naming
        const mFilterKeyMapping = {
          fileName: "filename",
          outputType: "formattype",
          printDate: "printdate",
        };

        // Loop through export data and create Filter objects
        for (let key in oData) {
          if (
            oData.hasOwnProperty(key) &&
            oData[key] !== null &&
            oData[key] !== undefined
          ) {
            let value = oData[key];
            let filterKey = mFilterKeyMapping[key] || key;

            let oFilter = new sap.ui.model.Filter({
              path: filterKey,
              operator: sap.ui.model.FilterOperator.EQ,
              value1: value,
            });
            aExportFilters.push(oFilter);
          }
        }
        let aCombinedFilters = aExportFilters;
        if (aFilterBarFilters && aFilterBarFilters.length > 0) {
          aCombinedFilters = aFilterBarFilters.concat(aExportFilters);
        }
        return aCombinedFilters;
      },
      fnDownloadFile: function (
        oDownloadData,
        sDefaultFileName = "REPORT.xlsx"
      ) {
        
        // Convert Base64 to Blob and Trigger File Download
        const base64Data = oDownloadData.DownloadFileContentBinary;
        const mimeType = oDownloadData.MimeType || "application/octet-stream";
        const filename = oDownloadData.filename || sDefaultFileName;

        // Convert Base64 to a Blob
        const byteCharacters = atob(base64Data);
        const byteNumbers = new Array(byteCharacters.length);
        for (let i = 0; i < byteCharacters.length; i++) {
          byteNumbers[i] = byteCharacters.charCodeAt(i);
        }
        const byteArray = new Uint8Array(byteNumbers);
        const fileBlob = new Blob([byteArray], { type: mimeType });

        const downloadLink = document.createElement("a");
        downloadLink.href = URL.createObjectURL(fileBlob);
        downloadLink.download = filename;
        document.body.appendChild(downloadLink);
        downloadLink.click();
        document.body.removeChild(downloadLink);
      },
      //End Export Handler

      fnAddHistoryButtonToSmartTableToolbar: function (
        oController,
        fnExportCallback
      ) {
        if (!oController) {
          console.clear();
          console.log(
            `fnAddHistoryButtonToSmartTableToolbar - Missing oController`
          );
          MessageBox.error(this.getGeneralTechnicalIssueMsg());
        }
        this.historyListReportController = oController;
        this._historyCallback = fnExportCallback;
        try {
          const oToolbar = oController._oListReport._oToolbar;
          if (!oToolbar) {
            return;
          }
          // Find the TablePersonalisation button
          const aToolbarContent = oToolbar.getContent();
          let iPersonalizationBtnIndex = -1;

          aToolbarContent.forEach(function (oControl, index) {
            if (
              oControl.getMetadata().getName() === "sap.m.Button" &&
              oControl.getIcon() === "sap-icon://action-settings"
            ) {
              iPersonalizationBtnIndex = index;
            }
          });

          //Create Export Excel Button
          let oButton = new sap.m.Button({
            text: "{i18n>HistoryBtn}",
            press: this._fnOnViewHistoryDataHandler.bind(this),
            customData: [
              new sap.ui.core.CustomData({
                key: "outputType",
                value: "1",
              }),
            ],
          });

          if (iPersonalizationBtnIndex !== -1) {
            oToolbar.insertContent(oButton, iPersonalizationBtnIndex + 1);
          } else {
            // If personalization button not found, add to end of toolbar
            oToolbar.addContent(oButton);
          }
        } catch (error) {
          console.clear();
          console.log(
            `fnAddExportMenuButtonToSmartTableToolbar error: ${error.stack}`
          );
          MessageBox.error(this.getGeneralTechnicalIssueMsg());
        }
      },
      _fnOnViewHistoryDataHandler: function (oEvent) {
        if (this._historyCallback) {
          this._historyCallback(oEvent);
        } else {
          MessageBox.error(this.getGeneralTechnicalIssueMsg());
        }
      },

      //Filter Handler
      fnGetFilterQueryString: function (oController) {
        try {
          const FILTER_DATE_KEYS = [
            "DateOfIssue",
            "ExpiryDate",
            "ValueDate",
            "StartDate",
            "ReturningDate",
            "InvalidDate",
          ];
          const aFilters = FilterCommon.buildFilters(
            oController,
            oController._oFilterBar,
            FILTER_DATE_KEYS
          );
          let sFilterQuery = FilterCommon.convertFiltersToODataString(aFilters);
          return sFilterQuery;
        } catch (error) {
          console.log(`fnGetFilterQueryString - error: ${error.stack}`);
          return "";
        }
      },

      readData: function (oModel, sEntityPath, aFilters) {
        this.showBusy();
        return new Promise(
          function (resolve, reject) {
            oModel.read(sEntityPath, {
              filters: aFilters,
              success: function (oData) {
                this.hideBusy();
                if (oData && oData.results && oData.results.length > 0) {
                  resolve(oData);
                } else {
                  MessageBox.information("No data found");
                }
              }.bind(this),
              error: function (oError) {
                this.hideBusy();
                reject(oError);
              }.bind(this),
            });
          }.bind(this)
        );
      },
      //End filter handler
      fnGetDataV2: function (oController, sRequestEndpoint) {
        const that = this;
        const oSettings = {
          headers: {
            "Accept-Language": this.getLanguage(),
          },
        };
        this.showBusy();
        return new Promise(function (resolve, reject) {
          HttpRequest.getData(
            sRequestEndpoint,
            (oData) => {
              that.hideBusy();
              if (oData.d && oData.d.results && oData.d.results.length > 0) {
                resolve(oData.d.results);
              }
              resolve([]);
            },
            (oError) => {
              //@ts-ignore
              console.log("fnGetDataV2 - Error: ", oError);
              resolve([]);
              // reject(oError);
              that.hideBusy();
            },
            oSettings
          );
        });
      },
      fnGetDataV4: function (oController, sRequestEndpoint) {
        const that = this;
        const oSettings = {
          headers: {
            "Accept-Language": this.getLanguage(),
          },
        };
        this.showBusy();
        return new Promise(function (resolve, reject) {
          HttpRequest.getData(
            sRequestEndpoint,
            (oData) => {
              that.hideBusy();
              if (oData.value && oData.value.length > 0) {
                resolve(oData.value);
              }
              resolve([]);
            },
            (oError) => {
              //@ts-ignore
              console.log("fnGetDataV4 - Error: ", oError);
              resolve([]);
              // reject(oError);
              that.hideBusy();
            },
            oSettings
          );
        });
      },
      getLanguage: function () {
        let sLangId = sap.ui.getCore().getConfiguration().getLanguage() || "en";
        return sLangId;
      },
      fnSetUserDefaultValue: function (oController) {
        // const currentVariantId = oController._oFilterBar.getCurrentVariantId();
        // const mainServiceEndpoint = oController
        //   .getView()
        //   .getModel().sServiceUrl;
        // if (currentVariantId == "" || currentVariantId == "standard") {
        //   const oCompanyCodeControl =
        //     oController._oFilterBar.getControlByKey("CompanyCode");
        //   this.fnHandleUserDefaultValue("CompanyCode", oCompanyCodeControl);

        //   const PRODUCT_TYPE_DEFAULT = ["55A"];
        //   const oProductTypeControl =
        //     oController._oFilterBar.getControlByKey("ProductType");
        //   const sProductTypeEndpoint =
        //     mainServiceEndpoint + "/ZI_FI_TM02_PRODTYPE_VH";
        //   this.fnSetMultiInputValues(
        //     PRODUCT_TYPE_DEFAULT,
        //     oProductTypeControl,
        //     sProductTypeEndpoint,
        //     "Sgsart",
        //     "Xtext"
        //   );
        // }
      },
      fnSetMultiInputValues: function (
        tokens,
        oControl,
        requestEndpoint,
        filterKey,
        filterTextKey
      ) {
        const oRequestF4Data = this.fnGetDataV2(this, requestEndpoint);
        $.when(oRequestF4Data).done((aF4List) => {
          let aDefaultTokens = [];
          tokens.forEach((token) => {
            const oToken = aF4List.find((oF4) => oF4[filterKey] === token);
            if (oToken) {
              aDefaultTokens.push(
                new Token({
                  key: oToken[filterKey],
                  text: `${oToken[filterKey]} (${oToken[filterTextKey]})`,
                })
              );
            }
          });
          oControl.setTokens(aDefaultTokens);
        });
      },
      fnHandleUserDefaultValue: function (
        userDefaultValueKey,
        oControl,
        defaultValues
      ) {
        if (!userDefaultValueKey || !oControl) {
          return; //invalid or control param do nothing
        }
        //Set Fixed value
        if (defaultValues) {
          oControl.setValue(defaultValues);
        }
        //Get UserDefaultParameters service
        sap.ushell.Container.getServiceAsync("UserDefaultParameters")
          .then(function (oUserDefaultParametersService) {
            //Set User default value here
            const oRequestUserDefaultValue =
              oUserDefaultParametersService.getValue(
                userDefaultValueKey,
                USER_DEFAULT_SYSTEM_CONTEXT
              );
            $.when(oRequestUserDefaultValue).done((oDefaultData) => {
              if (oDefaultData.value) {
                oControl.setValue(oDefaultData.value);
              }
              return;
            });
          })
          .catch(function (oError) {
            console.error("Failed to get UserDefaultParameters:", oError);
          });
      },
      getGeneralTechnicalIssueMsg: function () {
        return "Something went wrong. Please get in touch with the Technical team for support!";
      },
      fnAutoAdjustColumnWidth: function (oTable) {
        oTable.getColumns().forEach((oColumn, index) => {
          // oTable.autoResizeColumn(index);
        });
      },
      showBusy: function () {
        return sap.ui.core.BusyIndicator.show();
      },
      hideBusy: function () {
        sap.ui.core.BusyIndicator.hide();
      },
      //EOF
    };
  }
);
