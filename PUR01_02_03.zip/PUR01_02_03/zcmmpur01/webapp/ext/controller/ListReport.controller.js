const APP_MODULE = `zcmmpur01`;
const APP_NAMESPACE = `ngs.pvgas.${APP_MODULE}`;
const FRAGMENT_PATH = `${APP_NAMESPACE}.ext.fragments.`;

sap.ui.define(
  [
    `ngs/pvgas/${APP_MODULE}/ext/controller/Core.controller`,
    "sap/ui/model/json/JSONModel",
    "sap/ui/model/Filter",
    "sap/m/Button",
    "sap/m/MessageBox",
    "sap/m/Token",
    "sap/m/MessageView",
    'sap/m/MessageItem',
    'sap/ui/core/library',    
  ],

  function (Core, JSONModel, Filter, Button, MessageBox, Token, MessageView, MessageItem, coreLibrary) {
    "use strict";

    return {
      onInit: function () {
        const oJSONData = {};
        const oModel = new JSONModel(oJSONData);
        this.getView().setModel(oModel, "local");
        this._oView = this.getView();
        this._oComponent = this.getOwnerComponent();
        this._oExtensionAPI = this.extensionAPI;
        this._oFilterBar = Core.fnGetViewControl(this, "listReportFilter");
        this._oListReport = Core.fnGetViewControl(this, "listReport");
        // this._oTable = Core.fnGetViewControl(this, "analyticalTable");
        // if (!this._oFilterBar || !this._oListReport || !this._oTable) {
        //   MessageBox.error(Core.getGeneralTechnicalIssueMsg());
        //   return;
        // }

        // xu ly data dau vao
        console.log("Is FLP loaded?", sap.ushell && sap.ushell.Container);
        let oComponentData = this.getOwnerComponent().getComponentData();
        let oStartupParams = oComponentData && oComponentData.startupParameters;
        if (oStartupParams && oStartupParams.MyID) {
          const sMyID = oStartupParams.MyID[0]; // luôn là array
          console.log("Received MyID:", sMyID);
      
          // Gọi filter, binding hoặc hành động tùy vào logic của bạn
        }
        else {
          const oUriParams = new URLSearchParams(window.location.hash.split("?")[1]);
          const sMyID = oUriParams.get("MyID");
          console.log("Param from URL:", sMyID);
        }

        this._oFilterBar.attachInitialise(
          function (oEvent) {
            Core.fnSetUserDefaultValue(this);
          }.bind(this)
        );

        Core.fnAddHistoryButtonToSmartTableToolbar(
          this,
          this.onPressHistoryDataHandler
        );

        Core.fnAddUploadMenuButtonToSmartTableToolbar(
          this,
          this.onPressUploadDataHandler
        );

        Core.fnAddExportMenuButtonToSmartTableToolbar(
          this,
          this.onPressExportDataHandler
        );

        // this._oTable.attachEvent(
        //   "rowsUpdated",
        //   this.onTableDataUpdateFinished,
        //   this
        // );
      },
      onBeforeRebindTableExtension: function (oEvent) {

        // let oBindingParams = oEvent.getParameter("bindingParams");

        // oBindingParams.events = oBindingParams.events || {};

        // oBindingParams.events.dataReceived = function () {
        //   let aItems = this._oListReport.getItems( );

        //   aItems.forEach(
        //     function (oItem) { 
        //       let oContext = oItem.getBindingContext();
        //     }
        //   );
        // }.bind(this);

        const oSmartTable = this._oListReport;
        const oTable = oSmartTable.getTable();
      

        oTable.attachEventOnce("rowsUpdated", () => {
          const aColumns = oTable.getColumns();
          aColumns.forEach((oColumn, index) => {
            const oLabel = oColumn.getLabel();
            if (oLabel?.getText?.() === "Status") {
              // const oTemplate = new sap.m.Text({
              //   text: {
              //     path: "Status",
              //     formatter: function (sStatus) {
              //       // Gắn class qua DOM tại đây
              //       setTimeout(() => {
              //         const oDomRef = this.getDomRef?.();
              //         if (oDomRef) {
              //           oDomRef.classList.remove("statusErrorColor", "statusSuccessColor");
              //           if (sStatus === "Error") {
              //             oDomRef.classList.add("statusErrorColor");
              //           } else if (sStatus === "Success") {
              //             oDomRef.classList.add("statusSuccessColor");
              //           }
              //         }
              //       });                    
              //       return sStatus;
              //     }
              //   }
              // });

              const oTemplate = new sap.m.ObjectStatus({
                text: "{Status}",
                state: {
                  path: "Status",
                  formatter: function (sStatus) {
                    switch (sStatus) {
                      case "Error": return "Error";     // đỏ
                      case "Success": return "Success"; // xanh lá
                      case "Warning": return "Warning"; // vàng
                      default: return "None";           // mặc định
                    }
                  }
                }
              });

              oTemplate.addStyleClass("boldStatusText");

              oColumn.setTemplate(oTemplate);
            }

            // if (oLabel?.getText?.() === "ZZMESSAGE") {
            //   oColumn.setWidth("auto");
            // }

          });
        });

        if (oTable?.getColumns && oTable.autoResizeColumn) {
          // 💡 Tìm cột bạn muốn auto-resize, ví dụ "Message"
          const aColumns = oTable.getColumns();
          aColumns.forEach((oColumn, iIndex) => {
            const oLabel = oColumn.getLabel?.();
            if (oLabel?.getText?.() === "Message" || oLabel?.getText?.() === "File name") {
              oColumn.setAutoResizable(true);          // 👈 Kích hoạt resize
              setTimeout(() => {
              oTable.autoResizeColumn(iIndex);         // 👈 Gọi resize theo nội dung
              }, 500); // Thời gian delay để đảm bảo nội dung đã được render
            }
          });
        }        
      },      
      getLanguage: function () {
        return Core.getLanguage();
      },
      onTableDataUpdateFinished: function (oEvent) {
        // const aRows = this._oTable.getRows();
        // const aColumns = this._oTable.getColumns();
        // for (let i = 0; i < aColumns.length; i++) {
        //   const oColumn = aColumns[i];
        //   //to use this need add annotation @UI.lineItem: [{ position: 10, type: #AS_LINK, label: 'Document Number' }]
        //   // var oTemplate = oColumn.getTemplate();
        //   // if (oTemplate && oTemplate.isA("sap.m.Link")) {
        //   //     oTemplate.attachPress(this.onDocumentLinkPress, this);
        //   // }
        //   const sColumnHeader = oColumn.getLabel().getText(); // Get column header text
        //   if (sColumnHeader === "PDF" || sColumnHeader === "XML") {
        //     if (oColumn.getSummed() === true) {
        //       continue;
        //     }
        //     const oTemplate = oColumn.getTemplate();
        //     if (oTemplate && oTemplate.isA("sap.m.Text")) {
        //       const oLink = new sap.m.Link({
        //         text: oTemplate
        //           .getBindingInfo("text")
        //           .parts[0].path.toUpperCase(),
        //         customData: [
        //           new sap.ui.core.CustomData({
        //             key: "docType",
        //             value: oTemplate
        //               .getBindingInfo("text")
        //               .parts[0].path.toUpperCase(),
        //           }),
        //         ],
        //         press: this.onViewAttachments.bind(this),
        //       });
        //       oColumn.setTemplate(oLink);
        //     }
        //   }
        // }

        // for (let i = aRows.length - 5; i < aRows.length; i++) {
        //     const oRow = aRows[i];
        //     const oRowData = oRow.getCells()[1].getText();
        //     console.log(`dsad ${oRowData}`);
        // }
      },
      onViewAttachments: function (oEvent) {
        try {
          const oView = this.getView();
          const oAttachmentModelData = new JSONModel({
            title: "Attachments",
            items: [],
          });
          this.getView().setModel(oAttachmentModelData, "attachment");
          const oAttachmentModel = this.getView().getModel("attachment");
          const oSourcePress = oEvent.getSource();
          const docType = oSourcePress.getCustomData()[0].getValue();
          oAttachmentModel.setProperty("/title", `${docType} Files`);
          const oRowData = oSourcePress
            .getParent()
            .getBindingContext()
            .getObject();
          const attachmentQuery = `?$filter=((((CompanyCode eq '${oRowData.CompanyCode}')) and ((DocumentNumber eq '${oRowData.DocumentNumber}') and ((formattype eq '${docType}')))))`;
          const sRequestEndpoint = `${
            this.getModel().sServiceUrl
          }/attachment${attachmentQuery}`;
          const oRequestAttachments = Core.fnGetDataV2(this, sRequestEndpoint);
          $.when(oRequestAttachments).done((aContents) => {
            oAttachmentModel.setProperty("/items", aContents);
            if (!this._pAttachment) {
              this._pAttachment = this.loadFragment({
                id: oView.getId(),
                name: `${FRAGMENT_PATH}Attachments`,
                controller: this,
              }).then(function (oPopover) {
                oView.addDependent(oPopover);
                return oPopover;
              });
            }
            this._pAttachment.then(function (oPopover) {
              oPopover.openBy(oSourcePress);
            });
          });
        } catch (error) {
          console.log(`onViewAttachments - Error: ${error.stack}`);
          MessageBox.error(Core.getGeneralTechnicalIssueMsg());
        }
        console.log("onViewAttachments");
      },
      onPressAttachmentItem: function (oEvent) {
        const oSource = oEvent.getSource();
        const oAttachmentData = oSource
          .getBindingContext("attachment")
          .getObject();
        if (oAttachmentData.DownloadFileContentBinary) {
          Core.fnDownloadFile(oAttachmentData);
        }
      },
      _getLocalModelExportExcel: function (outputType) {
        // template 1 : Upload PR NHC
        // template 2 : Upload PR HC SLBT thang
        // template 3 : Upload PR HC_LPG_LNG
        
        // combobox:
        // SLBT thang (template 2)
        // LNG_LPN (template 3)
        // NHC (template 1)

        let templateName = "";
        let fileName = "";

        const now = new Date();

        // Lấy ngày dạng dd.mm.yyyy
        const day = String(now.getDate()).padStart(2, '0');
        const month = String(now.getMonth() + 1).padStart(2, '0'); // Tháng tính từ 0
        const year = now.getFullYear();
        const formattedDate = `${day}-${month}-${year}`;
        
        // Lấy giờ dạng hh.mm.ss
        const hours = String(now.getHours()).padStart(2, '0');
        const minutes = String(now.getMinutes()).padStart(2, '0');
        const seconds = String(now.getSeconds()).padStart(2, '0');
        const formattedTime = `${hours}-${minutes}-${seconds}`;

        // SLBT Thang
        if (outputType === 1) {
          templateName = "ZXF_ZCMMPUR01_TEMPLATE_02";
          fileName = "PVG_Template_Upload_PurchaseRequisition_SanLuongKhiBaoTieuThang_" + formattedDate + "_" + formattedTime;
        } else if (outputType === 2) {
          templateName = "ZXF_ZCMMPUR01_TEMPLATE_03";
          fileName = "PVG_Template_Upload_PurchaseRequisition_LPG_LNG_" + formattedDate + "_" + formattedTime;
        } else if (outputType === 3) {
          templateName = "ZXF_ZCMMPUR01_TEMPLATE_01";
          fileName = "PVG_Template_Upload_PurchaseRequisition_NHC_" + formattedDate + "_" + formattedTime;
        }

        let oTemplateModel = new JSONModel({
          fileName: fileName,
          templateName : templateName
        });

        return oTemplateModel; 
      },
      //START export
      onPressExportDataHandler: async function (outputType) {
        const oController = this.extListReportController;

        try {
          Core.showBusy();
          const exportDataModel = oController.getModel("downloadExcelSrv");
          let aExportFilters = [];

          // if ( outputType === "1" ) {
            // let formname = "ZXF_ZCMMPUR01_TEMPLATE_0" + outputType;
          // } else if ( outputType === "2" ) {
          //   formname = "ZXF_ZCMMPUR01_TEMPLATE_02";
          // } else if ( outputType === "3" ) {
          //   formname = "ZXF_ZCMMPUR01_TEMPLATE_03";
          // }  

          let oTemplateExel = oController._getLocalModelExportExcel(outputType);
          
          oController._oView.setModel(oTemplateExel, "excelTemplate");

          let templateName = oTemplateExel.getData().templateName;
          let fileName = oTemplateExel.getData().fileName;

          let oFilter = new sap.ui.model.Filter({
            path : "TemplateName",
            operator : sap.ui.model.FilterOperator.EQ,
            value1 : templateName,
          });
          aExportFilters.push(oFilter); 

          // // Filter key mapping for backend naming
          // const mFilterKeyMapping = {
          //   TemplateName: formname,
          // };
          
          const oData = await Core.readData(
            exportDataModel,
            '/DownloadExcel',
            aExportFilters
          );

          if (oData && oData.results && oData.results.length > 0) {
            const oDownloadData = oData.results[0];
            if (oDownloadData.DownloadFileContentBinary) {
              Core.fnDownloadFile(oDownloadData,fileName);
              if (this._oExportDataDialog) {
                this._oExportDataDialog.then(function (oDialog) {
                  oDialog.close();
                });
              }
            } else {
              MessageBox.information("No data found for export");
            }
          } else {
            MessageBox.information("No data found");
          }
        } catch (oError) {
          if (oError && oError.message) {
            console.error(
              "Error reading data:",
              oError.message ?? oError.stack
            );
          }
          MessageBox.error(Core.getGeneralTechnicalIssueMsg());
        }


        // let oExportDataModel = new JSONModel({
        //   fileName: "BaoCaoTinhHinhSuDungHanMucTrungDaiHan",
        //   outputType: outputType,
        //   printDate: new Date(),
        // });
        // oController._oView.setModel(oExportDataModel, "exportData");
        // if (!oController._oExportDataDialog) {
        //   oController._oExportDataDialog = oController.loadFragment({
        //     name: `${FRAGMENT_PATH}ExportDialog`,
        //   });
        // }
        // oController._oExportDataDialog.then(
        //   function (oDialog) {
        //     oDialog.open();
        //   }.bind(oController)
        // );
      },
      onCloseExportDataDialog: function () {
        if (this._oExportDataDialog) {
          this._oExportDataDialog.then(function (oDialog) {
            oDialog.close();
          });
        }
      },
      onConfirmExportData: async function () {
        try {
          Core.showBusy();
          const exportDataModel = this.getModel("exportDataModelSrv");
          let aExportFilters = Core.fnGetExportFilters(this);

          const oData = await Core.readData(
            exportDataModel,
            "/ExportExcel",
            aExportFilters
          );
          if (oData && oData.results && oData.results.length > 0) {
            const oDownloadData = oData.results[0];
            if (oDownloadData.DownloadFileContentBinary) {
              Core.fnDownloadFile(oDownloadData);
              if (this._oExportDataDialog) {
                this._oExportDataDialog.then(function (oDialog) {
                  oDialog.close();
                });
              }
            } else {
              MessageBox.information("No data found for export");
            }
          } else {
            MessageBox.information("No data found");
          }
        } catch (oError) {
          if (oError && oError.message) {
            console.error(
              "Error reading data:",
              oError.message ?? oError.stack
            );
          }
          MessageBox.error(Core.getGeneralTechnicalIssueMsg());
        }
      },
      //END export
      getExportSrvPath: function () {
        const oExportSrvModel = this.getModel("exportDataModelSrv");
        if (oExportSrvModel) {
          return `${oExportSrvModel.sServiceUrl}`;
        }
        return "";
      },
      //START Upload
      onPressUploadDataHandler: async function (outputType) {

        const oController = this.extListReportControllerUpload;

        // Clear the file uploader if it exists
        let oFileUploader = oController.byId("fileUploaderRawData");
        if (oFileUploader){
          oFileUploader.clear();
        }

        let oUploadDataModel = new JSONModel({
          fileName: "",
          outputType: outputType,
          printDate: new Date(),
          templateName: outputType,
        });
        oController._oView.setModel(oUploadDataModel, "uploadData");
        if (!oController._oUploadDataDialog) {
          oController._oUploadDataDialog = oController.loadFragment({
            name: `${FRAGMENT_PATH}UploadDialog`,
          });
        }
        oController._oUploadDataDialog.then(
          function (oDialog) {
            oDialog.open();
          }.bind(oController)
        ); 
        
        let oExcelModel = oController._getLocalModelExportExcel(outputType);
        oController.templateUploadName = oExcelModel.getData().templateName;

      },
      onCloseUploadDataDialog: function () {
        if (this._oUploadDataDialog) {
          this._oUploadDataDialog.then(function (oDialog) {
            oDialog.close();
          });
        } 
      },
      onConfirmUploadData(){
        if (!this.aFiles) {
          MessageBox.error("No file selected");
          return;
        }
        else if (this.aFiles) {
          if (this.aFiles.length === 0) {
            MessageBox.error("No file selected");
            return;
          }
        }

        this.fnUploadFile(this.aFiles[0])
        .then(function (sBase64) {
            // console.log("File converted to Base64:", sBase64);
            this._postData(sBase64);
            if (this._oUploadDataDialog) {
              this._oUploadDataDialog.then(function (oDialog) {
                oDialog.close();
              });
            }
        }.bind(this))
        .catch(function (sError) {
            console.error(sError);
        });
      },          
      onFilePathChange(oEvent) {
        if (this._oUploadDataDialog) {
          this._oUploadDataDialog.then(function (oDialog) {
            let oFileUploader = oEvent.getSource();
            let aFiles = oFileUploader.oFileUpload.files;
            if (aFiles.length === 0) {
              return;
            }
            this.sFileName = aFiles[0].name;
            this.aFiles = aFiles;
          }.bind(this));
        }        
      },
      onTypeMissMatch: function (oEvent) {
        if (this._oUploadDataDialog) {
          this._oUploadDataDialog.then(function (oDialog) {
            let oFileUploader = oEvent.getSource();
            let aFiles = oFileUploader.oFileUpload.files;

            if (aFiles.length === 0) {
              oFileUploader.clear();
              this.sFileName = "";
              this.aFiles = [];
              MessageBox.error("Your file must be in XLSX or XLS format");
              return;
            }

            const sfileName = aFiles[0].name;
            const sFileExtension = sfileName.split('.').pop().toLowerCase();

            if (sFileExtension !== "xlsx") {
              oFileUploader.clear();
              this.sFileName = "";
              this.aFiles = [];
              MessageBox.error("Your file must be in XLSX or XLS format");
              return;
            }

            this.sFileName = aFiles[0].name;
            this.aFiles = aFiles;
          }.bind(this));
        }
      },
      onBeforeDialogOpen: function (oEvent) {
        if (this._oUploadDataDialog) {
          this._oUploadDataDialog.then(function (oDialog) {
            let oFileUploader = oEvent.getSource();
            oFileUploader.clear();
          }.bind(this));
        }
      },
      fnUploadFile: async function (oFile) {
        return new Promise(function (resolve, reject) {
            // Kiểm tra nếu file tồn tại
            if (!oFile) {
                reject("No file provided for upload.");
                return;
            }
    
            // Sử dụng FileReader để đọc file
            var oReader = new FileReader();
    
            // Định nghĩa callback khi đọc file thành công
            oReader.onload = function (oEvent) {
                // Lấy nội dung file dưới dạng Base64
                var sBase64 = oEvent.target.result.split(",")[1]; // Loại bỏ tiền tố "data:*/*;base64,"
                resolve(sBase64); // Trả về chuỗi Base64
            };
    
            // Định nghĩa callback khi đọc file thất bại
            oReader.onerror = function (oError) {
                reject("Error reading file: " + oError.message);
            };
    
            // Đọc file dưới dạng Data URL (Base64)
            let vvrar = oReader.readAsDataURL(oFile);
            
        });
      },
      onCloseViewHistory: function () {
        if (this._oHistoryDataDialog) {
          this._oHistoryDataDialog.then(function (oDialog) {
            oDialog.getModel().resetChanges();
            oDialog.close();
          });
        }
      },      
      onGoViewHistory: function(oEvent, oThis, sValue){
        // const oController = this.historyListReportController;

        // const oHistoryDataModel = oController._oView.getModel("historyData");

        // const oHistoryDataModel = this._oView.getModel("historyData");

        // Bắt buộc đồng bộ lại data từ UI vào context
        // sap.ui.core.Fragment.byId(this.getView().getId(), "smartfield1")?.getBinding("value")?.checkUpdate(true);
        // sap.ui.core.Fragment.byId(this.getView().getId(), "smartfield2")?.getBinding("value")?.checkUpdate(true);
        // sap.ui.core.Fragment.byId(this.getView().getId(), "smartfield")?.getBinding("value")?.checkUpdate(true);

        var oDialog = oEvent.getSource().getParent();
        var oBindingContext = oDialog.getContent()[0].getBindingContext();
        var sObject = oBindingContext.getObject();



        if (!sObject.UPLOADFROMDATE) {
          MessageBox.error("Field 'From Date' is required");
          return;
        }

        if (!sObject.UPLOADTODATE) {
          MessageBox.error("Field 'To Date' is required");
          return;
        }

        // if (!sObject.CREATED_BY) {
        //   MessageBox.error("Field 'Created by' is required");
        //   return;
        // }

        const oCrossAppNav = sap.ushell.Container.getService("CrossApplicationNavigation");
        oCrossAppNav.toExternal({
          target: {
            semanticObject: "zcmmpur01his",
            action: "display"
          },
          // params: {
          //   UploadFromDate : [ oHistoryDataModel.getProperty("/uploadFromDate") ],
          //   UploadToDate : [ oHistoryDataModel.getProperty("/uploadToDate") ],
          //   UploadBy : [ oHistoryDataModel.getProperty("/uploadBy") ],
          // }
          params: {
            UploadFromDate : [ sObject.UPLOADFROMDATE ],
            UploadToDate : [ sObject.UPLOADTODATE  ],
            UploadBy : [ sObject.CREATED_BY  ],
          }    
        });
        
        if (this._oHistoryDataDialog) {
          this._oHistoryDataDialog.then(function (oDialog) {
            oDialog.getModel().resetChanges();
            oDialog.close();
          });
        }

      },            
      onPressHistoryDataHandler: async function (outputType) {

        // const oController = this.historyListReportController;
        // let oHistoryDataModel = new JSONModel({
        //   uploadFromDate: '',
        //   uploadToDate: '',
        //   uploadBy: '',
        // });
        // oController._oView.setModel(oHistoryDataModel, "historyData");
        // // if (!oController._oHistoryDataDialog) {
        //   oController._oHistoryDataDialog = oController.loadFragment({
        //     id: "idViewHistoryDlg",
        //     name: `${FRAGMENT_PATH}ViewHistoryDialog`,
        //     controller: oController,
        //   });
        // // }

        // var oView = oController.getView();

        // oController._oHistoryDataDialog.then(
        //   function (oDialog) {

        //     var oCreatedByArea = {CREATED_BY: "",
        //                           UPLOADFROMDATE: new Date(),
        //                           UPLOADTODATE: new Date(),
        //     };

        //     const oModel = oView.getModel();
        //     oModel.create("/VHCreatedBy", oCreatedByArea, {
        //       success: function (oResult) {
        //         const oCreateEntry = oModel.createEntry("/VHCreatedBy", {
        //           properties: oResult,
        //         });
        //         oDialog.open();
        //         oDialog.getContent()[0].setBindingContext(oCreateEntry);
        //       },
        //       error: function () {},
        //     });

        //     oDialog.attachEventOnce("afterClose", function () {
        //       oDialog.destroy();
        //     });

        //     // oDialog.open();
        //   }.bind(oController)
        // );  

        const oCrossAppNav = sap.ushell.Container.getService("CrossApplicationNavigation");
        oCrossAppNav.toExternal({
          target: {
            semanticObject: "zcmmpur01his",
            action: "display"
          }
        });

        // const oController = this.historyListReportController;

        // const oCrossAppNav = sap.ushell.Container.getService("CrossApplicationNavigation");
        // oCrossAppNav.toExternal({
        //   target: {
        //     semanticObject: "zcmmpur01his",
        //     action: "display"
        //   },
        //   params: {
        //     UploadFromDate : [ "12345" ],
        //     UploadToDate : [ "54321" ],
        //     UploadBy : [ "ABC" ],
        //   }
        // });

        // try {
        //   Core.showBusy();
        //   const exportDataModel = oController.getModel("downloadExcelSrv");
        //   let aExportFilters = [];

        //   // if ( outputType === "1" ) {
        //     let formname = "ZXF_ZCMMPUR01_TEMPLATE_0" + outputType;
        //   // } else if ( outputType === "2" ) {
        //   //   formname = "ZXF_ZCMMPUR01_TEMPLATE_02";
        //   // } else if ( outputType === "3" ) {
        //   //   formname = "ZXF_ZCMMPUR01_TEMPLATE_03";
        //   // }

        //   let oFilter = new sap.ui.model.Filter({
        //     path : "TemplateName",
        //     operator : sap.ui.model.FilterOperator.EQ,
        //     value1 : formname,
        //   });
        //   aExportFilters.push(oFilter); 

        //   // // Filter key mapping for backend naming
        //   // const mFilterKeyMapping = {
        //   //   TemplateName: formname,
        //   // };
          
        //   const oData = await Core.readData(
        //     exportDataModel,
        //     '/DownloadExcel',
        //     aExportFilters
        //   );

        //   if (oData && oData.results && oData.results.length > 0) {
        //     const oDownloadData = oData.results[0];
        //     if (oDownloadData.DownloadFileContentBinary) {
        //       Core.fnDownloadFile(oDownloadData,formname);
        //       if (this._oExportDataDialog) {
        //         this._oExportDataDialog.then(function (oDialog) {
        //           oDialog.close();
        //         });
        //       }
        //     } else {
        //       MessageBox.information("No data found for export");
        //     }
        //   } else {
        //     MessageBox.information("No data found");
        //   }
        // } catch (oError) {
        //   if (oError && oError.message) {
        //     console.error(
        //       "Error reading data:",
        //       oError.message ?? oError.stack
        //     );
        //   }
        //   MessageBox.error(Core.getGeneralTechnicalIssueMsg());
        // }
      },
      formatStatusColor: function (sStatus) {
        if (sStatus === "Error") {
          return "sapUiNegativeText"; // màu đỏ
        } else if (sStatus === "Success") {
          return "sapUiPositiveText"; // màu xanh lá
        } else {
          return ""; // mặc định
        }
      },

      showErrorsSequentially(aMessages) {
        if (!aMessages || aMessages.length === 0) {
          return;
        }

        var oMessageTemplate = new MessageItem({
          type: '{type}',
          title: '{title}',
          activeTitle: '{activeTitle}',
          description: '{description}',
          subtitle: '{subtitle}',
          counter: '{counter}',
          markupDescription: '{markupDescription}'
        });
  
      // 1. Map array string -> object
        var aMessageObjects  = aMessages.map(function(sText) {
          return {
              type: "Error",
              title: sText,
              description: ""
          };
        });
  
        var oModel = new JSONModel();
  
        oModel.setData(aMessageObjects);
  
        this.oMessageView = new MessageView({
          showDetailsPageHeader: false,
          itemSelect: function () {
            oBackButton.setVisible(true);
          },
          items: {
            path: "/",
            template: oMessageTemplate
          },
          activeTitlePress: function () {
            MessageToast.show('Active title pressed');
          }
        });

        var oBackButton = new Button({
            icon: sap.ui.core.IconPool.getIconURI("nav-back"),
            visible: false,
            press: function () {
              that.oMessageView.navigateBack();
              this.setVisible(false);
            }
          });
  
  
  
        this.oMessageView.setModel(oModel);
  
	      // // shortcut for sap.ui.core.TitleLevel
	      var TitleLevel = coreLibrary.TitleLevel;

        this.oDialog = new sap.m.Dialog({
          resizable: false,
          content: this.oMessageView,
          state: 'Error',
          title: "Error",
          beginButton: new Button({
            press: function () {
              this.getParent().close();
            },
            text: "Close"
          }),
          customHeader: new sap.m.Bar({
            contentLeft: [oBackButton],
            contentMiddle: [
              new sap.m.Title({
                text: "Error",
                level: TitleLevel.H1
              })
            ]
          }),
          contentHeight: "38%",
          contentWidth: "38%",
          verticalScrolling: false
        });
        
        this.oDialog.open();        

        // let i = 0;
      
        // const showNext = function () {
        //   if (i >= aMessages.length) {
        //     return;
        //   }
      
        //   MessageBox.error(aMessages[i], {
        //     onClose: function () {
        //       i++;
        //       showNext(); // Gọi cái tiếp theo sau khi cái trước đóng
        //     }
        //   });
        // };
      
        // showNext();
      },

      _postData: async function (sBase64) {
        try {
          Core.showBusy();
          const exportDataModel = this.getModel("uploadExcelSrv"); 
          let oEntry = new JSONModel({
            TEMPLATE_NAME: this.templateUploadName,
            FILE_NAME: this.sFileName,
            BINARY_DATA: sBase64,
            ToMessageReturnSet: [],
          });
  
          new Promise( 
            function (resolve, reject) { 
              exportDataModel.create("/ExcelFileSet", oEntry.oData, {
                method: "POST",
                success: function (oData) {
                  Core.hideBusy();
                  if (oData && oData.ToMessageReturnSet && oData.ToMessageReturnSet.results.length > 0) {
                    let finalfilter = "";

                    let isError = '';

                    for ( let i = 0; i < oData.ToMessageReturnSet.results.length; i++) {
                      const oMessage = oData.ToMessageReturnSet.results[i];
                      if (oMessage.ZZSTATUS === "-") {
                        isError = 'X';
                      }
                      else if (oMessage.ZZMESSAGE) {
                        isError = 'X';
                      }
                      else {
                        // let oListReportModel = this._oListReport.getModel();
                                                
                        let oALV = [];
                        const currentVariantId = this._oFilterBar.getCurrentVariantId();
                        const oFile_UploadController = this._oFilterBar.getControlByKey("ZZIDFILE_UPLOAD");
                        const oDate_UploadController = this._oFilterBar.getControlByKey("ZZDATE_UPLOAD");
                        // const oTime_UploadController = this._oFilterBar.getControlByKey("ZZTIME_UPLOAD");

                        // for (let j = 0; j < oData.ToMessageReturnSet.results.length; j++) {
                        //   let oMessageReturn = oData.ToMessageReturnSet.results[j];

                          // oALV.push( new JSONModel({  
                          //   Status: oMessageReturn.ZZSTATUS,
                          //   ZZID_PR: oMessageReturn.ZZID_PR,
                          //   ZZSHEET: oMessageReturn.ZZSHEET,
                          //   ZZMESSAGE: oMessageReturn.ZZMESSAGE,
                          //   BANFN: oMessageReturn.BANFN,
                          //   ZZIDFILE_UPLOAD: oMessageReturn.ZZIDFILE_UPLOAD,
                          //   ZZDATE_UPLOAD: oMessageReturn.ZZDATE_UPLOAD,
                          //   Currency: "",
                          //   CreditLimit: 0,
                          // }) );
                        // }

                        if (currentVariantId == "" || currentVariantId == "standard") {
                          let aDefaultTokens = [];
                          aDefaultTokens.push(
                            new Token({
                              key: oMessage.ZZIDFILE_UPLOAD,
                            })
                          );
                          oFile_UploadController.setTokens(aDefaultTokens);

                          const year = parseInt(oMessage.ZZDATE_UPLOAD.substring(0, 4), 10);
                          const month = parseInt(oMessage.ZZDATE_UPLOAD.substring(4, 6), 10) - 1; // Tháng tính từ 0!
                          const day = parseInt(oMessage.ZZDATE_UPLOAD.substring(6, 8), 10); 

                          // const zzdate_update_conv = new Date( `${year}-${month}-${day}` );

                          const zzdate_update_conv = new Date(year, month, day, 7);

                          aDefaultTokens = [];
                          aDefaultTokens.push(
                            new Token({
                              key: zzdate_update_conv,
                            })
                          );
                          oDate_UploadController.setTokens(aDefaultTokens);

                          // aDefaultTokens = [];
                          // aDefaultTokens.push(
                          //   new Token({
                          //     key: oMessage.ZZTIME_UPLOAD,
                          //   })
                          // );
                          // oTime_UploadController.setTokens(aDefaultTokens);


                        } 

                        finalfilter = "ZZIDFILE_UPLOAD eq '" + oMessage.ZZIDFILE_UPLOAD + "'" + " and ZZDATE_UPLOAD eq '" + oMessage.ZZDATE_UPLOAD + "'";

                        let oTable = this._oListReport.getTable();
                        // oTable.setModel(oALV, "");
                        oTable.bindRows({
                          path: "/PUR01",
                          parameters: {
                            $filter: finalfilter,
                          }
                        });

                        // this.aFiles = [];

                        this._oListReport.rebindTable();
                      }
                    }

                    if (isError === 'X') {
                      const aMessages = oData.ToMessageReturnSet.results
                      .filter(m => m.ZZSTATUS === "-" || m.ZZMESSAGE)
                      .map(m => m.ZZMESSAGE);

                      this.showErrorsSequentially(aMessages);
                    }

                    // for (let i = 0; i < oData.ToMessageReturnSet.results.length; i++) {
                    //   const oMessage = oData.ToMessageReturnSet.results[i];
                    //   if (oMessage.ZZSTATUS === "-") {
                    //     MessageBox.error(oMessage.ZZMESSAGE, {
                    //       onClose: function () {
                    //         setTimeout(() => {
                    //           i++;
                    //           showNext();
                    //         }, 200); // delay nhẹ để tránh chồng chéo
                    //       }
                    //     }

                    //     );
                    //   } 
                    //   else if (oMessage.ZZMESSAGE) {
                    //     MessageBox.error(oMessage.ZZMESSAGE,{
                    //       onClose: function () {
                    //         setTimeout(() => {
                    //           i++;
                    //           showNext();
                    //         }, 200); // delay nhẹ để tránh chồng chéo
                    //       }
                    //     }
                    //     );
                    //   }
                    //   else {
                    //     // let oListReportModel = this._oListReport.getModel();
                        
                    //     let oALV = [];
                    //     const currentVariantId = this._oFilterBar.getCurrentVariantId();
                    //     const oFile_UploadController = this._oFilterBar.getControlByKey("ZZIDFILE_UPLOAD");
                    //     const oDate_UploadController = this._oFilterBar.getControlByKey("ZZDATE_UPLOAD");
                    //     // const oTime_UploadController = this._oFilterBar.getControlByKey("ZZTIME_UPLOAD");

                    //     // for (let j = 0; j < oData.ToMessageReturnSet.results.length; j++) {
                    //     //   let oMessageReturn = oData.ToMessageReturnSet.results[j];

                    //       // oALV.push( new JSONModel({  
                    //       //   Status: oMessageReturn.ZZSTATUS,
                    //       //   ZZID_PR: oMessageReturn.ZZID_PR,
                    //       //   ZZSHEET: oMessageReturn.ZZSHEET,
                    //       //   ZZMESSAGE: oMessageReturn.ZZMESSAGE,
                    //       //   BANFN: oMessageReturn.BANFN,
                    //       //   ZZIDFILE_UPLOAD: oMessageReturn.ZZIDFILE_UPLOAD,
                    //       //   ZZDATE_UPLOAD: oMessageReturn.ZZDATE_UPLOAD,
                    //       //   Currency: "",
                    //       //   CreditLimit: 0,
                    //       // }) );
                    //     // }
                        
                    //     if (currentVariantId == "" || currentVariantId == "standard") {
                    //       let aDefaultTokens = [];
                    //       aDefaultTokens.push(
                    //         new Token({
                    //           key: oMessage.ZZIDFILE_UPLOAD,
                    //         })
                    //       );
                    //       oFile_UploadController.setTokens(aDefaultTokens);

                    //       const year = parseInt(oMessage.ZZDATE_UPLOAD.substring(0, 4), 10);
                    //       const month = parseInt(oMessage.ZZDATE_UPLOAD.substring(4, 6), 10) - 1; // Tháng tính từ 0!
                    //       const day = parseInt(oMessage.ZZDATE_UPLOAD.substring(6, 8), 10); 

                    //       // const zzdate_update_conv = new Date( `${year}-${month}-${day}` );

                    //       const zzdate_update_conv = new Date(year, month, day, 7);

                    //       aDefaultTokens = [];
                    //       aDefaultTokens.push(
                    //         new Token({
                    //           key: zzdate_update_conv,
                    //         })
                    //       );
                    //       oDate_UploadController.setTokens(aDefaultTokens);

                    //       // aDefaultTokens = [];
                    //       // aDefaultTokens.push(
                    //       //   new Token({
                    //       //     key: oMessage.ZZTIME_UPLOAD,
                    //       //   })
                    //       // );
                    //       // oTime_UploadController.setTokens(aDefaultTokens);


                    //     } 

                    //     finalfilter = "ZZIDFILE_UPLOAD eq '" + oMessage.ZZIDFILE_UPLOAD + "'" + " and ZZDATE_UPLOAD eq '" + oMessage.ZZDATE_UPLOAD + "'";
                        
                    //     let oTable = this._oListReport.getTable();
                    //     // oTable.setModel(oALV, "");
                    //     oTable.bindRows({
                    //       path: "/PUR01",
                    //       parameters: {
                    //         $filter: finalfilter,
                    //       }
                    //     });
                        
                    //     // this.aFiles = [];

                    //     this._oListReport.rebindTable();
                                              
                    //   }
                    // }

                    this.sFileName = "";
                    this.aFiles = [];


                        // this._oTable.getModel("local").setProperty("/items", oALV);

                        // this._oListReport.setModel(oALV,"");
                        




                        // let oBinding = this._oTable.getBinding("rows"); // 'rows' for AnalyticalTable
                        // if (oBinding) {
                        //   // oBinding.setModel(oALV,"");
                        //   // oBinding.rebindTable();
                        //   oBinding.refresh();
                        // }    

                        // oListReportModel.oData.results = oALV;
                        // oListReportModel.refresh(true);


                    resolve(oData);
                  } else {
                    MessageBox.information("No data found");
                  }
                }.bind(this),
                error: function (oError) {
                  this.hideBusy();
                  reject(oError);
                }.bind(this),
              });
          }.bind(this));
        } catch (error) {
          if (oError && oError.message) {
            console.error(
              "Error reading data:",
              oError.message ?? oError.stack
            );
          }
          MessageBox.error(Core.getGeneralTechnicalIssueMsg());
        } 
      },          
      /**
       * Convenience method for getting model.
       * @public
       * @returns {Object} the object model
       */
      getModel: function (sName) {
        return this.getView().getModel(sName);
      },

      /**
       * Convenience method for accessing the router.
       * @public
       * @returns {Object} the object model
       */
      setModel: function (oModel, sName) {
        return this.getView().setModel(oModel, sName);
      },
      onBeforeRendering: function () {},
      //EOF
    };
  }
);
