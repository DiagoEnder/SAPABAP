/**
 * Filters Common handler
 * created by: TinhLeo
 * created Date: 11/03/2025
 * Change logs:
 *  - 11/03/2025 (TinhLeo): Initial version
 * */
const UI_COMMON_IMPORT_MODULE = `zcmmpur02`;
sap.ui.define([
    `ngs/pvgas/${UI_COMMON_IMPORT_MODULE}/ext/common/UICommon`,
    "sap/ui/model/Filter",
    "sap/ui/model/FilterOperator",
], function (UICommon, Filter, FilterOperator) {
    "use strict";
    return {
        oController: null,
        buildFilters: function (oController, oScreenFilter,aDateKeys = []) {
            let aAllFilters = oScreenFilter.getFilters();
            aAllFilters[0] = this.changeFormatDateFilter(aAllFilters[0], aDateKeys);
            if (aAllFilters[0].aFilters) {
                if (aAllFilters[0].aFilters.length == 0) {
                    return [];
                }
                return aAllFilters[0].aFilters;
            }
            return [];
        },
        changeFormatDateFilter: function (oFilter, aDateKeys) {
            for (var i = 0; i < oFilter.aFilters.length; i++) {
                if (!oFilter.aFilters[i].sPath && oFilter.aFilters[i].aFilters) {
                    // Check each filter in the nested filters array
                    for (var j = 0; j < oFilter.aFilters[i].aFilters.length; j++) {
                        const currentFilter = oFilter.aFilters[i].aFilters[j];
                        if (currentFilter.sPath && aDateKeys.includes(currentFilter.sPath)) {
                            // Format the date values if they exist
                            if (currentFilter.oValue1) {
                                currentFilter.oValue1 = UICommon.formatDateFilter(currentFilter.oValue1);
                            }
                            if (currentFilter.oValue2) {
                                currentFilter.oValue2 = UICommon.formatDateFilter(currentFilter.oValue2);
                            }
                        }
                    }
                }
            }

            return oFilter;
        },

        convertFiltersToODataString: function (aFilters) {
            if (aFilters.length == 0) {
                return "";
            }
            const convertSingleFilter = (filter) => {
                const operatorMap = {
                    "EQ": "eq",
                    "NE": "ne",
                    "GT": "gt",
                    "GE": "ge",
                    "LT": "lt",
                    "LE": "le",
                    "BT": "ge",
                    "Contains": "contains"
                };

                if (filter._bMultiFilter) {
                    const subFilters = filter.aFilters.map(convertSingleFilter).filter(Boolean);
                    const conjunction = filter.bAnd ? " and " : " or ";
                    if (subFilters.length == 0) {
                        return "";
                    }
                    return `(${subFilters.join(conjunction)})`;
                } else {
                    const operator = operatorMap[filter.sOperator];
                    if (filter.sOperator === "BT") {
                        return `((${filter.sPath} ${operatorMap["GE"]} ${filter.oValue1} and ${filter.sPath} ${operatorMap["LE"]} ${filter.oValue2}))`;
                    } else if (filter.sOperator === "Contains") {
                        return `contains(${filter.sPath}, '${filter.oValue1}')`;
                    } else {
                        return `${filter.sPath} ${operator} '${filter.oValue1}'`;
                    }
                }
            };

            return aFilters.map(convertSingleFilter).filter(Boolean).join(" and ");
        }
        //EOF
    };
});